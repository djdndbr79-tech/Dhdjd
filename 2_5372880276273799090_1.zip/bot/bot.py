import asyncio
import json
import logging
import os
import aiosqlite
from datetime import datetime
from typing import Optional, List, Dict, Any
from io import BytesIO

from aiogram import Bot, Dispatcher, Router, F, types
from aiogram.filters import Command, CommandStart
from aiogram.types import (
    Message, CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup,
    InlineQueryResultArticle, InputTextMessageContent, InlineQuery,
    FSInputFile, BufferedInputFile
)
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
import aiohttp

# Config
BOT_TOKEN = "8590904457:AAH508WQwV3a1TdEHh_jtUYGHM86Mpw-Q_I"
ADMIN_ID = 8030989657
WEBAPP_URL = "https://kinomir-v2.vercel.app"
API_URL = "https://kinomir-v2.vercel.app/api"

# TMDB API for movie data
TMDB_API_KEY = "2dca580c2a14b55200e784d157207b4d"
TMDB_BASE = "https://api.themoviedb.org/3"
TMDB_IMAGE = "https://image.tmdb.org/t/p/w500"

# Database
DB_PATH = "/tmp/kinomir_bot.db"

# Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Bot setup
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())
router = Router()
dp.include_router(router)

# States for admin
class AdminStates(StatesGroup):
    broadcast_text = State()
    broadcast_photo = State()
    broadcast_video = State()
    broadcast_file = State()

# Database functions
async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                telegram_id INTEGER UNIQUE,
                username TEXT,
                first_name TEXT,
                last_name TEXT,
                movies_watched INTEGER DEFAULT 0,
                series_watched INTEGER DEFAULT 0,
                favorite_genre TEXT DEFAULT '—',
                watch_time INTEGER DEFAULT 0,
                is_banned INTEGER DEFAULT 0,
                created_at TEXT,
                updated_at TEXT
            )
        ''')
        await db.execute('''
            CREATE TABLE IF NOT EXISTS watch_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                movie_id TEXT,
                movie_title TEXT,
                movie_type TEXT,
                poster TEXT,
                watched_at TEXT,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        ''')
        await db.execute('''
            CREATE TABLE IF NOT EXISTS shares (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                movie_id TEXT,
                movie_title TEXT,
                movie_type TEXT,
                poster TEXT,
                share_code TEXT UNIQUE,
                created_by INTEGER,
                created_at TEXT
            )
        ''')
        await db.commit()

async def get_or_create_user(user: types.User) -> Dict:
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            'SELECT * FROM users WHERE telegram_id = ?', (user.id,)
        )
        row = await cursor.fetchone()
        
        if row:
            return {
                'id': row[0],
                'telegram_id': row[1],
                'username': row[2],
                'first_name': row[3],
                'last_name': row[4],
                'movies_watched': row[5],
                'series_watched': row[6],
                'favorite_genre': row[7],
                'watch_time': row[8],
                'is_banned': row[9],
                'created_at': row[10],
                'updated_at': row[11]
            }
        
        now = datetime.now().isoformat()
        await db.execute(
            '''INSERT INTO users 
               (telegram_id, username, first_name, last_name, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?)''',
            (user.id, user.username, user.first_name, user.last_name, now, now)
        )
        await db.commit()
        
        return {
            'id': 1,
            'telegram_id': user.id,
            'username': user.username,
            'first_name': user.first_name,
            'last_name': user.last_name,
            'movies_watched': 0,
            'series_watched': 0,
            'favorite_genre': '—',
            'watch_time': 0,
            'is_banned': 0,
            'created_at': now,
            'updated_at': now
        }

async def update_user_watch(telegram_id: int, movie_id: str, title: str, mtype: str, poster: str, genres: List[str] = None):
    async with aiosqlite.connect(DB_PATH) as db:
        # Get user
        cursor = await db.execute('SELECT id FROM users WHERE telegram_id = ?', (telegram_id,))
        row = await cursor.fetchone()
        if not row:
            return
        
        user_id = row[0]
        now = datetime.now().isoformat()
        
        # Add to history
        await db.execute(
            '''INSERT INTO watch_history (user_id, movie_id, movie_title, movie_type, poster, watched_at)
               VALUES (?, ?, ?, ?, ?, ?)''',
            (user_id, movie_id, title, mtype, poster, now)
        )
        
        # Update stats
        if mtype == 'movie':
            await db.execute(
                'UPDATE users SET movies_watched = movies_watched + 1, updated_at = ? WHERE telegram_id = ?',
                (now, telegram_id)
            )
        else:
            await db.execute(
                'UPDATE users SET series_watched = series_watched + 1, updated_at = ? WHERE telegram_id = ?',
                (now, telegram_id)
            )
        
        await db.commit()

async def get_user_stats(telegram_id: int) -> Dict:
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            'SELECT movies_watched, series_watched, favorite_genre, watch_time FROM users WHERE telegram_id = ?',
            (telegram_id,)
        )
        row = await cursor.fetchone()
        if row:
            return {
                'movies': row[0],
                'series': row[1],
                'genre': row[2],
                'time': row[3]
            }
        return {'movies': 0, 'series': 0, 'genre': '—', 'time': 0}

async def get_all_users() -> List[Dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute('SELECT telegram_id, username, first_name, is_banned FROM users')
        rows = await cursor.fetchall()
        return [{'id': r[0], 'username': r[1], 'name': r[2], 'banned': r[3]} for r in rows]

async def ban_user(telegram_id: int, ban: bool = True):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            'UPDATE users SET is_banned = ? WHERE telegram_id = ?',
            (1 if ban else 0, telegram_id)
        )
        await db.commit()

async def is_user_banned(telegram_id: int) -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute('SELECT is_banned FROM users WHERE telegram_id = ?', (telegram_id,))
        row = await cursor.fetchone()
        return row and row[0] == 1

# Movie search functions
async def search_movies(query: str) -> List[Dict]:
    async with aiohttp.ClientSession() as session:
        url = f"{TMDB_BASE}/search/multi?api_key={TMDB_API_KEY}&language=ru&query={query}&page=1"
        async with session.get(url) as resp:
            data = await resp.json()
        
        results = []
        for item in data.get('results', [])[:10]:
            if item.get('media_type') in ['movie', 'tv']:
                results.append({
                    'id': item['id'],
                    'title': item.get('title') or item.get('name'),
                    'original_title': item.get('original_title') or item.get('original_name'),
                    'poster': f"{TMDB_IMAGE}{item['poster_path']}" if item.get('poster_path') else None,
                    'year': (item.get('release_date') or item.get('first_air_date') or '')[:4],
                    'rating': round(item.get('vote_average', 0), 1),
                    'overview': item.get('overview', '')[:300],
                    'type': 'movie' if item['media_type'] == 'movie' else 'tv'
                })
        return results

async def get_movie_details(movie_id: str, mtype: str) -> Optional[Dict]:
    async with aiohttp.ClientSession() as session:
        url = f"{TMDB_BASE}/{mtype}/{movie_id}?api_key={TMDB_API_KEY}&language=ru"
        async with session.get(url) as resp:
            if resp.status != 200:
                return None
            data = await resp.json()
        
        genres = [g['name'] for g in data.get('genres', [])]
        
        return {
            'id': movie_id,
            'title': data.get('title') or data.get('name'),
            'original_title': data.get('original_title') or data.get('original_name'),
            'poster': f"{TMDB_IMAGE}{data['poster_path']}" if data.get('poster_path') else None,
            'backdrop': f"https://image.tmdb.org/t/p/original{data['backdrop_path']}" if data.get('backdrop_path') else None,
            'year': (data.get('release_date') or data.get('first_air_date') or '')[:4],
            'rating': round(data.get('vote_average', 0), 1),
            'votes': data.get('vote_count', 0),
            'runtime': data.get('runtime') or data.get('episode_run_time', [0])[0],
            'overview': data.get('overview'),
            'genres': genres,
            'country': (data.get('production_countries') or [{}])[0].get('name'),
            'type': mtype
        }

# Share functionality
import random
import string

def generate_share_code():
    return ''.join(random.choices(string.ascii_letters + string.digits, k=8))

async def create_share(movie_id: str, title: str, mtype: str, poster: str, user_id: int) -> str:
    code = generate_share_code()
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            '''INSERT INTO shares (movie_id, movie_title, movie_type, poster, share_code, created_by, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)''',
            (movie_id, title, mtype, poster, code, user_id, datetime.now().isoformat())
        )
        await db.commit()
    return code

async def get_share(code: str) -> Optional[Dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute('SELECT * FROM shares WHERE share_code = ?', (code,))
        row = await cursor.fetchone()
        if row:
            return {
                'movie_id': row[1],
                'title': row[2],
                'type': row[3],
                'poster': row[4]
            }
        return None

# Keyboard builders
def main_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="🎬 Каталог", web_app=types.WebAppInfo(url=WEBAPP_URL))
    )
    builder.row(
        InlineKeyboardButton(text="🔍 Поиск", switch_inline_query_current_chat=""),
        InlineKeyboardButton(text="👤 Профиль", callback_data="profile")
    )
    builder.row(
        InlineKeyboardButton(text="🌟 Топ фильмов", callback_data="top_movies"),
        InlineKeyboardButton(text="📺 Топ сериалов", callback_data="top_series")
    )
    return builder.as_markup()

def movie_keyboard(movie_id: str, mtype: str, title: str, poster: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    watch_url = f"{WEBAPP_URL}?movie={movie_id}&type={mtype}"
    builder.row(
        InlineKeyboardButton(text="▶️ Смотреть", web_app=types.WebAppInfo(url=watch_url))
    )
    builder.row(
        InlineKeyboardButton(text="📤 Поделиться", callback_data=f"share_{movie_id}_{mtype}"),
        InlineKeyboardButton(text="❤️ В избранное", callback_data=f"fav_{movie_id}_{mtype}")
    )
    return builder.as_markup()

def back_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="◀️ Назад", callback_data="main_menu"))
    return builder.as_markup()

def admin_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="📢 Рассылка (текст)", callback_data="admin_broadcast_text"),
        InlineKeyboardButton(text="📷 Рассылка (фото)", callback_data="admin_broadcast_photo")
    )
    builder.row(
        InlineKeyboardButton(text="🎬 Рассылка (видео)", callback_data="admin_broadcast_video"),
        InlineKeyboardButton(text="📁 Рассылка (файл)", callback_data="admin_broadcast_file")
    )
    builder.row(
        InlineKeyboardButton(text="📊 Статистика", callback_data="admin_stats"),
        InlineKeyboardButton(text="👥 Пользователи", callback_data="admin_users")
    )
    builder.row(
        InlineKeyboardButton(text="📋 Экспорт ID", callback_data="admin_export")
    )
    return builder.as_markup()

# Handlers
@router.message(CommandStart())
async def cmd_start(message: Message):
    if await is_user_banned(message.from_user.id):
        await message.answer("⛔ Вы заблокированы")
        return
    
    user = await get_or_create_user(message.from_user)
    
    # Check for share code in deep link
    args = message.text.split()[1:] if len(message.text.split()) > 1 else []
    if args and args[0].startswith('share_'):
        code = args[0].replace('share_', '')
        share = await get_share(code)
        if share:
            movie = await get_movie_details(share['movie_id'], share['type'])
            if movie:
                text = format_movie_message(movie)
                await message.answer_photo(
                    photo=movie['poster'] or 'https://via.placeholder.com/500x750',
                    caption=text,
                    parse_mode="HTML",
                    reply_markup=movie_keyboard(movie['id'], movie['type'], movie['title'], movie['poster'])
                )
                return
    
    name = user.get('first_name') or user.get('username') or 'друг'
    await message.answer(
        f"👋 Привет, {name}!\n\n"
        f"🎬 Добро пожаловать в <b>KinoMir</b> — премиум онлайн кинотеатр!\n\n"
        f"Здесь ты найдёшь тысячи фильмов и сериалов в отличном качестве.\n\n"
        f"Используй меню ниже для навигации:",
        parse_mode="HTML",
        reply_markup=main_keyboard()
    )

@router.message(Command("profile"))
@router.callback_query(F.data == "profile")
async def show_profile(event: Message | CallbackQuery):
    if isinstance(event, CallbackQuery):
        message = event.message
        user_id = event.from_user.id
    else:
        message = event
        user_id = event.from_user.id
    
    if await is_user_banned(user_id):
        await message.answer("⛔ Вы заблокированы")
        return
    
    user = await get_or_create_user(event.from_user)
    stats = await get_user_stats(user_id)
    
    hours = stats['time'] // 60
    minutes = stats['time'] % 60
    
    text = (
        f"👤 <b>Твой профиль</b>\n\n"
        f"📝 Имя: {user.get('first_name') or user.get('username', 'Не указано')}\n"
        f"👤 Username: @{user.get('username') or 'не указан'}\n\n"
        f"📊 <b>Статистика:</b>\n"
        f"🎬 Фильмов просмотрено: {stats['movies']}\n"
        f"📺 Сериалов просмотрено: {stats['series']}\n"
        f"⏱️ Время просмотра: {hours}ч {minutes}мин\n"
        f"❤️ Любимый жанр: {stats['genre']}\n\n"
        f"📅 Регистрация: {user.get('created_at', '—')[:10]}"
    )
    
    if isinstance(event, CallbackQuery):
        await event.answer()
        await message.edit_text(text, parse_mode="HTML", reply_markup=back_keyboard())
    else:
        await message.answer(text, parse_mode="HTML", reply_markup=back_keyboard())

@router.callback_query(F.data == "main_menu")
async def main_menu(callback: CallbackQuery):
    await callback.message.edit_text(
        "🎬 <b>KinoMir</b> — главное меню",
        parse_mode="HTML",
        reply_markup=main_keyboard()
    )

@router.callback_query(F.data == "top_movies")
async def top_movies(callback: CallbackQuery):
    async with aiohttp.ClientSession() as session:
        url = f"{TMDB_BASE}/movie/top_rated?api_key={TMDB_API_KEY}&language=ru&page=1"
        async with session.get(url) as resp:
            data = await resp.json()
    
    text = "🌟 <b>Топ фильмов</b>\n\n"
    for i, m in enumerate(data.get('results', [])[:10], 1):
        rating = round(m.get('vote_average', 0), 1)
        year = (m.get('release_date') or '')[:4]
        text += f"{i}. <b>{m['title']}</b> ({year})\n   ⭐ {rating}\n\n"
    
    await callback.message.edit_text(text, parse_mode="HTML", reply_markup=back_keyboard())

@router.callback_query(F.data == "top_series")
async def top_series(callback: CallbackQuery):
    async with aiohttp.ClientSession() as session:
        url = f"{TMDB_BASE}/tv/top_rated?api_key={TMDB_API_KEY}&language=ru&page=1"
        async with session.get(url) as resp:
            data = await resp.json()
    
    text = "📺 <b>Топ сериалов</b>\n\n"
    for i, m in enumerate(data.get('results', [])[:10], 1):
        rating = round(m.get('vote_average', 0), 1)
        year = (m.get('first_air_date') or '')[:4]
        text += f"{i}. <b>{m['name']}</b> ({year})\n   ⭐ {rating}\n\n"
    
    await callback.message.edit_text(text, parse_mode="HTML", reply_markup=back_keyboard())

def format_movie_message(movie: Dict) -> str:
    genres_str = ', '.join(movie.get('genres', [])[:3])
    year = movie.get('year', '')
    rating = movie.get('rating', 0)
    runtime = movie.get('runtime', 0)
    overview = movie.get('overview', 'Нет описания')[:400]
    type_label = "Фильм" if movie['type'] == 'movie' else "Сериал"
    
    text = (
        f"{'🎬' if movie['type'] == 'movie' else '📺'} <b>{movie['title']}</b>\n"
    )
    
    if movie.get('original_title') and movie['original_title'] != movie['title']:
        text += f"🌐 <i>{movie['original_title']}</i>\n"
    
    text += (
        f"\n"
        f"📅 Год: {year}\n"
        f"⭐ Рейтинг: {rating}/10\n"
        f"⏱️ Длительность: {runtime} мин.\n"
        f"🎭 Жанры: {genres_str}\n\n"
        f"📝 <b>Описание:</b>\n{overview}...\n\n"
        f"📌 #{type_label}"
    )
    
    return text

# Inline search
@router.inline_query()
async def inline_search(query: InlineQuery):
    if not query.query:
        return
    
    movies = await search_movies(query.query)
    
    results = []
    for movie in movies:
        text = f"🎬 {movie['title']} ({movie['year']})\n⭐ {movie['rating']}/10\n\nНажмите для просмотра"
        
        results.append(
            InlineQueryResultArticle(
                id=f"{movie['id']}_{movie['type']}",
                title=movie['title'],
                description=f"{movie['year']} • ⭐ {movie['rating']} • {'Фильм' if movie['type'] == 'movie' else 'Сериал'}",
                thumbnail_url=movie['poster'],
                input_message_content=InputTextMessageContent(
                    message_text=f"🎬 Выбрано: {movie['title']}\n\nНажмите кнопку ниже для просмотра"
                ),
                reply_markup=movie_keyboard(str(movie['id']), movie['type'], movie['title'], movie['poster'])
            )
        )
    
    await query.answer(results[:20], cache_time=60)

# Share handler
@router.callback_query(F.data.startswith("share_"))
async def share_movie(callback: CallbackQuery):
    _, movie_id, mtype = callback.data.split("_")
    
    movie = await get_movie_details(movie_id, mtype)
    if not movie:
        await callback.answer("Фильм не найден", show_alert=True)
        return
    
    code = await create_share(movie_id, movie['title'], mtype, movie['poster'], callback.from_user.id)
    share_link = f"https://t.me/kinomir_bot?start=share_{code}"
    
    await callback.answer(f"Ссылка скопирована!", show_alert=False)
    
    await callback.message.answer(
        f"📤 <b>Ссылка для шаринга:</b>\n\n"
        f"<code>{share_link}</code>\n\n"
        f"Отправь эту ссылку другу, и он увидит фильм!",
        parse_mode="HTML"
    )

# Admin handlers
@router.message(Command("admin"))
async def admin_panel(message: Message):
    if message.from_user.id != ADMIN_ID:
        await message.answer("⛔ Нет доступа")
        return
    
    await message.answer(
        "👑 <b>Админ панель</b>",
        parse_mode="HTML",
        reply_markup=admin_keyboard()
    )

@router.callback_query(F.data.startswith("admin_"))
async def admin_callback(callback: CallbackQuery, state: FSMContext):
    if callback.from_user.id != ADMIN_ID:
        await callback.answer("⛔ Нет доступа")
        return
    
    action = callback.data.replace("admin_", "")
    
    if action == "broadcast_text":
        await callback.message.edit_text(
            "📝 <b>Рассылка текста</b>\n\nОтправьте текст для рассылки:",
            parse_mode="HTML"
        )
        await state.set_state(AdminStates.broadcast_text)
    
    elif action == "broadcast_photo":
        await callback.message.edit_text(
            "📷 <b>Рассылка фото</b>\n\nОтправьте фото с подписью:",
            parse_mode="HTML"
        )
        await state.set_state(AdminStates.broadcast_photo)
    
    elif action == "broadcast_video":
        await callback.message.edit_text(
            "🎬 <b>Рассылка видео</b>\n\nОтправьте видео с подписью:",
            parse_mode="HTML"
        )
        await state.set_state(AdminStates.broadcast_video)
    
    elif action == "broadcast_file":
        await callback.message.edit_text(
            "📁 <b>Рассылка файла</b>\n\nОтправьте файл с подписью:",
            parse_mode="HTML"
        )
        await state.set_state(AdminStates.broadcast_file)
    
    elif action == "stats":
        users = await get_all_users()
        total = len(users)
        active = sum(1 for u in users if not u['banned'])
        banned = total - active
        
        text = (
            f"📊 <b>Статистика</b>\n\n"
            f"👥 Всего пользователей: {total}\n"
            f"✅ Активных: {active}\n"
            f"⛔ Заблокированных: {banned}"
        )
        await callback.message.edit_text(text, parse_mode="HTML", reply_markup=admin_keyboard())
    
    elif action == "users":
        users = await get_all_users()
        text = "👥 <b>Пользователи</b> (последние 20):\n\n"
        for u in users[:20]:
            status = "⛔" if u['banned'] else "✅"
            text += f"{status} {u['name']} (@{u['username']}) - ID: {u['id']}\n"
        
        await callback.message.edit_text(text, parse_mode="HTML", reply_markup=admin_keyboard())
    
    elif action == "export":
        users = await get_all_users()
        ids = "\n".join([str(u['id']) for u in users])
        
        file = BufferedInputFile(ids.encode(), filename="users.txt")
        await callback.message.answer_document(file, caption="📋 Экспорт ID пользователей")
        await callback.answer()

# Broadcast handlers
@router.message(AdminStates.broadcast_text)
async def broadcast_text(message: Message, state: FSMContext):
    users = await get_all_users()
    success = 0
    failed = 0
    
    await message.answer(f"📤 Начинаю рассылку {len(users)} пользователям...")
    
    for user in users:
        if user['banned']:
            continue
        try:
            await bot.send_message(user['id'], message.text, parse_mode="HTML")
            success += 1
        except:
            failed += 1
        await asyncio.sleep(0.05)
    
    await message.answer(f"✅ Рассылка завершена!\n\nУспешно: {success}\nОшибок: {failed}")
    await state.clear()

@router.message(AdminStates.broadcast_photo)
async def broadcast_photo(message: Message, state: FSMContext):
    if not message.photo:
        await message.answer("Отправьте фото!")
        return
    
    users = await get_all_users()
    photo = message.photo[-1].file_id
    caption = message.caption or ""
    success = 0
    failed = 0
    
    await message.answer(f"📤 Начинаю рассылку {len(users)} пользователям...")
    
    for user in users:
        if user['banned']:
            continue
        try:
            await bot.send_photo(user['id'], photo, caption=caption, parse_mode="HTML")
            success += 1
        except:
            failed += 1
        await asyncio.sleep(0.05)
    
    await message.answer(f"✅ Рассылка завершена!\n\nУспешно: {success}\nОшибок: {failed}")
    await state.clear()

@router.message(AdminStates.broadcast_video)
async def broadcast_video(message: Message, state: FSMContext):
    if not message.video:
        await message.answer("Отправьте видео!")
        return
    
    users = await get_all_users()
    video = message.video.file_id
    caption = message.caption or ""
    success = 0
    failed = 0
    
    await message.answer(f"📤 Начинаю рассылку {len(users)} пользователям...")
    
    for user in users:
        if user['banned']:
            continue
        try:
            await bot.send_video(user['id'], video, caption=caption, parse_mode="HTML")
            success += 1
        except:
            failed += 1
        await asyncio.sleep(0.05)
    
    await message.answer(f"✅ Рассылка завершена!\n\nУспешно: {success}\nОшибок: {failed}")
    await state.clear()

@router.message(AdminStates.broadcast_file)
async def broadcast_file(message: Message, state: FSMContext):
    if not message.document:
        await message.answer("Отправьте файл!")
        return
    
    users = await get_all_users()
    file_id = message.document.file_id
    caption = message.caption or ""
    success = 0
    failed = 0
    
    await message.answer(f"📤 Начинаю рассылку {len(users)} пользователям...")
    
    for user in users:
        if user['banned']:
            continue
        try:
            await bot.send_document(user['id'], file_id, caption=caption, parse_mode="HTML")
            success += 1
        except:
            failed += 1
        await asyncio.sleep(0.05)
    
    await message.answer(f"✅ Рассылка завершена!\n\nУспешно: {success}\nОшибок: {failed}")
    await state.clear()

# Ban command
@router.message(Command("ban"))
async def ban_user_cmd(message: Message):
    if message.from_user.id != ADMIN_ID:
        return
    
    args = message.text.split()[1:]
    if not args:
        await message.answer("Использование: /ban <user_id>")
        return
    
    try:
        user_id = int(args[0])
        await ban_user(user_id, True)
        await message.answer(f"⛔ Пользователь {user_id} заблокирован")
    except:
        await message.answer("Ошибка")

@router.message(Command("unban"))
async def unban_user_cmd(message: Message):
    if message.from_user.id != ADMIN_ID:
        return
    
    args = message.text.split()[1:]
    if not args:
        await message.answer("Использование: /unban <user_id>")
        return
    
    try:
        user_id = int(args[0])
        await ban_user(user_id, False)
        await message.answer(f"✅ Пользователь {user_id} разблокирован")
    except:
        await message.answer("Ошибка")

# Main
async def main():
    await init_db()
    logger.info("Bot starting...")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
