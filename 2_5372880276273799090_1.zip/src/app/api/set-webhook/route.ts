import { NextRequest, NextResponse } from 'next/server'

const BOT_TOKEN = "8590904457:AAH508WQwV3a1TdEHh_jtUYGHM86Mpw-Q_I"

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const secret = searchParams.get('secret')
  
  // Simple auth check
  if (secret !== 'kinomir_admin_2024') {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }
  
  // Get the host from request
  const host = req.headers.get('host') || 'kinomir-v2.vercel.app'
  const webhookUrl = `https://${host}/api/bot`
  
  // Set webhook
  const res = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/setWebhook`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      url: webhookUrl,
      allowed_updates: ['message', 'callback_query', 'inline_query']
    })
  })
  
  const data = await res.json()
  
  // Also get webhook info
  const infoRes = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/getWebhookInfo`)
  const info = await infoRes.json()
  
  return NextResponse.json({
    webhookSet: data,
    webhookUrl,
    webhookInfo: info
  })
}
