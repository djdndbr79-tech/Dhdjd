import { NextRequest, NextResponse } from 'next/server'

// Config
const BOT_TOKEN = "8590904457:AAH508WQwV3a1TdEHh_jtUYGHM86Mpw-Q_I"
const ADMIN_ID = 8030989657
const WEBAPP_URL = "https://my-project-blue-two.vercel.app"
const TMDB_API_KEY = "2dca580c2a14b55200e784d157207b4d"
const TMDB_BASE = "https://api.themoviedb.org/3"
const TMDB_IMAGE = "https://image.tmdb.org/t/p/w500"

// JSON Blob storage (free, persistent)
const JSON_BLOB_ID = "019d2b87-79b7-7ae5-949c-324dac5e5ced"
const JSON_BLOB_URL = `https://jsonblob.com/api/jsonBlob/${JSON_BLOB_ID}`

// Storage interface
interface StorageData {
  total_users: number
  users: Record<number, {
    id: number
    username?: string
    first_name?: string
    last_name?: string
    created_at: string
    movies_watched?: number
    series_watched?: number
    watch_time?: number
    favorite_genre?: string
  }>
  admin_state?: {
    action: string
    data?: any
    timestamp: number
  }
}

// Admin states (in memory for current session)
const adminStates: Map<number, { action: string; data?: any }> = new Map()

// Get storage data
async function getStorage(): Promise<StorageData> {
  try {
    const res = await fetch(JSON_BLOB_URL, {
      cache: 'no-store',
      headers: { Accept: 'application/json' }
    })
    if (res.ok) {
      const data = await res.json()
      // Recalculate total_users based on actual users count
      const actualCount = Object.keys(data.users || {}).length
      if (data.total_users !== actualCount) {
        data.total_users = actualCount
        await saveStorage(data)
        console.log('[STORAGE] Fixed user count:', actualCount)
      }
      return data
    }
  } catch (err) {
    console.error('[STORAGE ERROR] Get:', err)
  }
  return { total_users: 0, users: {} }
}

// Save storage data
async function saveStorage(data: StorageData): Promise<boolean> {
  try {
    // Always sync total_users with actual count
    data.total_users = Object.keys(data.users || {}).length
    
    const res = await fetch(JSON_BLOB_URL, {
      method: 'PUT',
      headers: { 
        'Content-Type': 'application/json',
        Accept: 'application/json'
      },
      body: JSON.stringify(data)
    })
    return res.ok
  } catch (err) {
    console.error('[STORAGE ERROR] Save:', err)
    return false
  }
}

// Register user and return total count
async function registerUser(userId: number, from: any): Promise<{ isNew: boolean; totalUsers: number }> {
  const storage = await getStorage()
  
  if (storage.users[userId]) {
    // Update existing user info
    storage.users[userId] = {
      ...storage.users[userId],
      username: from.username,
      first_name: from.first_name,
      last_name: from.last_name
    }
    await saveStorage(storage)
    return { isNew: false, totalUsers: storage.total_users }
  }
  
  // New user
  storage.users[userId] = {
    id: userId,
    username: from.username,
    first_name: from.first_name,
    last_name: from.last_name,
    created_at: new Date().toISOString()
  }
  storage.total_users = Object.keys(storage.users).length
  
  await saveStorage(storage)
  console.log('[USER] New user:', userId, 'Total:', storage.total_users)
  
  return { isNew: true, totalUsers: storage.total_users }
}

// Get total users count
async function getTotalUsers(): Promise<number> {
  const storage = await getStorage()
  return storage.total_users
}

// Get all user IDs
async function getAllUserIds(): Promise<number[]> {
  const storage = await getStorage()
  return Object.keys(storage.users).map(Number)
}

// Get user data
async function getUserData(userId: number): Promise<any> {
  const storage = await getStorage()
  return storage.users[userId] || null
}

// Update user stats
async function updateUserStats(userId: number, stats: Partial<any>): Promise<void> {
  const storage = await getStorage()
  if (storage.users[userId]) {
    storage.users[userId] = { ...storage.users[userId], ...stats }
    await saveStorage(storage)
  }
}

// Telegram API helper
async function tg(method: string, params: Record<string, any> = {}) {
  const url = `https://api.telegram.org/bot${BOT_TOKEN}/${method}`
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params)
    })
    const data = await res.json()
    console.log(`[TG] ${method}:`, JSON.stringify(data).slice(0, 200))
    return data
  } catch (err) {
    console.error(`[TG ERROR] ${method}:`, err)
    return { ok: false, error: String(err) }
  }
}

// TMDB search
async function searchMovies(query: string): Promise<any[]> {
  try {
    const url = `${TMDB_BASE}/search/multi?api_key=${TMDB_API_KEY}&language=ru&query=${encodeURIComponent(query)}&page=1&include_adult=false`
    console.log('[TMDB] Searching:', query)
    
    const res = await fetch(url, { cache: 'no-store' })
    if (!res.ok) return []
    
    const data = await res.json()
    console.log('[TMDB] Results:', data.results?.length || 0)
    
    if (!data.results) return []
    
    return data.results
      .filter((item: any) => item.media_type === 'movie' || item.media_type === 'tv')
      .slice(0, 20)
      .map((item: any) => ({
        id: item.id,
        title: item.title || item.name || 'Unknown',
        poster: item.poster_path ? `${TMDB_IMAGE}${item.poster_path}` : null,
        year: (item.release_date || item.first_air_date || '').slice(0, 4) || '—',
        rating: Math.round((item.vote_average || 0) * 10) / 10,
        type: item.media_type === 'movie' ? 'movie' : 'tv',
        overview: (item.overview || '').slice(0, 100)
      }))
  } catch (err) {
    console.error('[TMDB ERROR]:', err)
    return []
  }
}

async function getMovieDetails(id: string, type: string) {
  const url = `${TMDB_BASE}/${type}/${id}?api_key=${TMDB_API_KEY}&language=ru`
  const res = await fetch(url, { cache: 'no-store' })
  if (!res.ok) return null
  const data = await res.json()
  
  return {
    id: data.id,
    title: data.title || data.name,
    original_title: data.original_title || data.original_name,
    poster: data.poster_path ? `${TMDB_IMAGE}${data.poster_path}` : null,
    backdrop: data.backdrop_path ? `https://image.tmdb.org/t/p/original${data.backdrop_path}` : null,
    year: (data.release_date || data.first_air_date || '').slice(0, 4),
    rating: Math.round((data.vote_average || 0) * 10) / 10,
    votes: data.vote_count || 0,
    runtime: data.runtime || (data.episode_run_time || [0])[0],
    overview: data.overview || '',
    genres: (data.genres || []).map((g: any) => g.name),
    country: (data.production_countries || [{}])[0]?.name || '',
    type
  }
}

// Keyboards
function mainKeyboard() {
  return {
    inline_keyboard: [
      [{ text: "🎬 Каталог", web_app: { url: WEBAPP_URL } }],
      [
        { text: "🔍 Поиск", switch_inline_query_current_chat: "" },
        { text: "👤 Профиль", callback_data: "profile" }
      ],
      [
        { text: "🌟 Топ фильмов", callback_data: "top_movies" },
        { text: "📺 Топ сериалов", callback_data: "top_series" }
      ]
    ]
  }
}

function movieKeyboard(movieId: string, type: string) {
  const watchUrl = `${WEBAPP_URL}?movie=${movieId}&type=${type}`
  return {
    inline_keyboard: [
      [{ text: "▶️ Смотреть", web_app: { url: watchUrl } }],
      [
        { text: "📤 Поделиться", url: `https://t.me/share/url?url=${encodeURIComponent(`https://t.me/kinomirs_bot?start=movie_${movieId}_${type}`)}&text=${encodeURIComponent('Смотри этот фильм!')}` },
        { text: "❤️ В избранное", callback_data: `fav_${movieId}_${type}` }
      ]
    ]
  }
}

function backKeyboard() {
  return {
    inline_keyboard: [
      [{ text: "◀️ Назад", callback_data: "main_menu" }]
    ]
  }
}

function adminKeyboard() {
  return {
    inline_keyboard: [
      [
        { text: "📊 Статистика", callback_data: "admin_stats" },
        { text: "👥 Пользователи", callback_data: "admin_users" }
      ],
      [
        { text: "📢 Рассылка", callback_data: "admin_broadcast" },
        { text: "📋 Экспорт ID", callback_data: "admin_export" }
      ],
      [{ text: "🔄 Синхронизировать", callback_data: "admin_sync" }]
    ]
  }
}

function adminBroadcastKeyboard() {
  return {
    inline_keyboard: [
      [
        { text: "✅ Отправить", callback_data: "admin_broadcast_confirm" },
        { text: "❌ Отмена", callback_data: "admin_broadcast_cancel" }
      ]
    ]
  }
}

function formatMovie(movie: any) {
  const genres = (movie.genres || []).slice(0, 3).join(', ')
  const typeLabel = movie.type === 'movie' ? 'Фильм' : 'Сериал'
  
  let text = `${movie.type === 'movie' ? '🎬' : '📺'} <b>${movie.title}</b>\n`
  
  if (movie.original_title && movie.original_title !== movie.title) {
    text += `🌐 <i>${movie.original_title}</i>\n`
  }
  
  text += `\n📅 Год: ${movie.year}\n`
  text += `⭐ Рейтинг: ${movie.rating}/10\n`
  if (movie.runtime) text += `⏱️ Длительность: ${movie.runtime} мин.\n`
  if (genres) text += `🎭 Жанры: ${genres}\n`
  text += `\n📝 <b>Описание:</b>\n${(movie.overview || 'Нет описания').slice(0, 400)}...\n\n`
  text += `📌 #${typeLabel}`
  
  return text
}

// Handle inline query
async function handleInlineQuery(inlineQuery: any) {
  const query = inlineQuery.query || ''
  const queryId = inlineQuery.id
  
  console.log('[INLINE] Query:', query)
  
  if (!query.trim()) {
    await tg('answerInlineQuery', {
      inline_query_id: queryId,
      results: [{
        type: 'article',
        id: 'help_1',
        title: '🔍 Введите название фильма',
        description: 'Например: матрица, интерстеллар, мстители',
        input_message_content: {
          message_text: '🔍 <b>Поиск фильмов в KinoMir</b>\n\nВведите название фильма после @kinomirs_bot\n\nПример: <code>@kinomirs_bot матрица</code>',
          parse_mode: 'HTML'
        }
      }],
      cache_time: 0
    })
    return
  }
  
  const movies = await searchMovies(query)
  
  if (movies.length === 0) {
    await tg('answerInlineQuery', {
      inline_query_id: queryId,
      results: [{
        type: 'article',
        id: 'no_results',
        title: '😕 Ничего не найдено',
        description: 'Попробуйте другое название',
        input_message_content: {
          message_text: `🔍 По запросу "<b>${query}</b>" ничего не найдено.`,
          parse_mode: 'HTML'
        }
      }],
      cache_time: 0
    })
    return
  }
  
  const results = movies.map((m: any) => {
    const movieCode = `${m.type}_${m.id}`
    const watchUrl = `${WEBAPP_URL}?movie=${m.id}&type=${m.type}`
    const typeLabel = m.type === 'movie' ? '🎬 Фильм' : '📺 Сериал'
    
    return {
      type: 'article',
      id: movieCode,
      title: m.title,
      description: `${m.year} • ⭐ ${m.rating}/10 • ${m.type === 'movie' ? 'Фильм' : 'Сериал'}`,
      thumb_url: m.poster || `https://via.placeholder.com/100x150/1a1a2e/ff2d92?text=${encodeURIComponent(m.type === 'movie' ? '🎬' : '📺')}`,
      input_message_content: {
        message_text: `${typeLabel} <b>${m.title}</b>\n📅 ${m.year} • ⭐ ${m.rating}/10\n\n🔗 Код: <code>${movieCode}</code>`,
        parse_mode: 'HTML'
      },
      reply_markup: {
        inline_keyboard: [
          [{ text: "▶️ Смотреть", web_app: { url: watchUrl } }],
          [{ text: "📤 Поделиться", url: `https://t.me/share/url?url=${encodeURIComponent(`https://t.me/kinomirs_bot?start=movie_${m.id}_${m.type}`)}&text=${encodeURIComponent('🎬 Смотри: ' + m.title)}` }]
        ]
      }
    }
  })
  
  await tg('answerInlineQuery', {
    inline_query_id: queryId,
    results: results,
    cache_time: 30,
    is_personal: false
  })
}

// Broadcast message to all users
async function broadcastMessage(message: string, adminId: number) {
  const userIds = await getAllUserIds()
  let sent = 0
  let failed = 0
  
  await tg('sendMessage', {
    chat_id: adminId,
    text: `📢 <b>Начинаю рассылку...</b>\n\n👥 Получателей: ${userIds.length}`,
    parse_mode: 'HTML'
  })
  
  for (const userId of userIds) {
    try {
      const result = await tg('sendMessage', {
        chat_id: userId,
        text: message,
        parse_mode: 'HTML',
        disable_web_page_preview: false
      })
      
      if (result.ok) {
        sent++
      } else {
        failed++
        console.log('[BROADCAST] Failed for user', userId, result.error)
      }
      
      // Rate limiting - 30 messages per second
      await new Promise(r => setTimeout(r, 35))
      
      // Progress update every 20 users
      if ((sent + failed) % 20 === 0) {
        await tg('sendMessage', {
          chat_id: adminId,
          text: `📢 Прогресс: ${sent + failed}/${userIds.length} (✅ ${sent} ❌ ${failed})`,
          parse_mode: 'HTML'
        })
      }
    } catch (err) {
      failed++
    }
  }
  
  await tg('sendMessage', {
    chat_id: adminId,
    text: `✅ <b>Рассылка завершена!</b>\n\n👥 Всего: ${userIds.length}\n✅ Отправлено: ${sent}\n❌ Не доставлено: ${failed}`,
    parse_mode: 'HTML',
    reply_markup: adminKeyboard()
  })
  
  return { sent, failed, total: userIds.length }
}

// Handle update
async function handleUpdate(update: any) {
  // Handle inline query FIRST
  if (update.inline_query) {
    await handleInlineQuery(update.inline_query)
    return
  }
  
  // Handle message
  if (update.message) {
    const msg = update.message
    const userId = msg.from?.id
    console.log('[MESSAGE] From:', userId, 'Text:', msg.text?.slice(0, 50))
    
    if (!userId) return
    
    // Register user
    const { isNew, totalUsers } = await registerUser(userId, msg.from)
    if (isNew) {
      console.log('[USER] Total users:', totalUsers)
    }
    
    // Check for admin state (broadcast message input)
    const adminState = adminStates.get(userId)
    if (adminState && adminState.action === 'awaiting_broadcast' && msg.text) {
      adminStates.set(userId, { action: 'broadcast_ready', data: { message: msg.text } })
      
      await tg('sendMessage', {
        chat_id: userId,
        text: `📢 <b>Предпросмотр рассылки:</b>\n\n${msg.text}\n\n⚠️ Отправить всем пользователям?`,
        parse_mode: 'HTML',
        reply_markup: adminBroadcastKeyboard()
      })
      return
    }
    
    // /start command
    if (msg.text?.startsWith('/start')) {
      const args = msg.text.split(' ').slice(1)
      
      // Deep link
      if (args.length > 0 && args[0].startsWith('movie_')) {
        const parts = args[0].split('_')
        if (parts.length >= 3) {
          const movie = await getMovieDetails(parts[2], parts[1])
          if (movie) {
            await tg('sendPhoto', {
              chat_id: userId,
              photo: movie.poster || 'https://via.placeholder.com/500x750',
              caption: formatMovie(movie),
              parse_mode: 'HTML',
              reply_markup: movieKeyboard(movie.id, movie.type)
            })
            return
          }
        }
      }
      
      const name = msg.from?.first_name || msg.from?.username || 'друг'
      await tg('sendMessage', {
        chat_id: userId,
        text: `👋 Привет, ${name}!\n\n🎬 Добро пожаловать в <b>KinoMir</b> — премиум онлайн кинотеатр!\n\nЗдесь ты найдёшь тысячи фильмов и сериалов в отличном качестве.\n\n💡 <b>Как искать:</b>\nНапиши @kinomirs_bot и название фильма\n\nИспользуй меню ниже:`,
        parse_mode: 'HTML',
        reply_markup: mainKeyboard()
      })
      return
    }
    
    // /profile command
    if (msg.text?.startsWith('/profile')) {
      const userData = await getUserData(userId)
      const stats = userData || {}
      const hours = Math.floor((stats.watch_time || 0) / 60)
      const minutes = (stats.watch_time || 0) % 60
      
      const text = `👤 <b>Твой профиль</b>\n\n` +
        `📝 Имя: ${stats.first_name || stats.username || 'Не указано'}\n` +
        `👤 Username: @${stats.username || 'не указан'}\n\n` +
        `📊 <b>Статистика:</b>\n` +
        `🎬 Фильмов просмотрено: ${stats.movies_watched || 0}\n` +
        `📺 Сериалов просмотрено: ${stats.series_watched || 0}\n` +
        `⏱️ Время просмотра: ${hours}ч ${minutes}мин\n` +
        `❤️ Любимый жанр: ${stats.favorite_genre || '—'}\n\n` +
        `📅 Регистрация: ${(stats.created_at || '').slice(0, 10)}`
      
      await tg('sendMessage', {
        chat_id: userId,
        text,
        parse_mode: 'HTML',
        reply_markup: backKeyboard()
      })
      return
    }
    
    // /admin command
    if (msg.text?.startsWith('/admin')) {
      if (userId !== ADMIN_ID) {
        await tg('sendMessage', { chat_id: userId, text: "⛔ Нет доступа" })
        return
      }
      
      const totalUsers = await getTotalUsers()
      await tg('sendMessage', {
        chat_id: userId,
        text: `👑 <b>Админ панель</b>\n\n👥 Всего пользователей: ${totalUsers}`,
        parse_mode: 'HTML',
        reply_markup: adminKeyboard()
      })
      return
    }
  }
  
  // Handle callback query
  if (update.callback_query) {
    const cb = update.callback_query
    const userId = cb.from?.id
    const data = cb.data
    
    if (!userId || !data) return
    
    // Register user
    await registerUser(userId, cb.from)
    
    if (data === 'main_menu') {
      await tg('editMessageText', {
        chat_id: userId,
        message_id: cb.message?.message_id,
        text: "🎬 <b>KinoMir</b> — главное меню",
        parse_mode: 'HTML',
        reply_markup: mainKeyboard()
      })
      await tg('answerCallbackQuery', { callback_query_id: cb.id })
      return
    }
    
    if (data === 'profile') {
      const userData = await getUserData(userId)
      const stats = userData || {}
      const hours = Math.floor((stats.watch_time || 0) / 60)
      const minutes = (stats.watch_time || 0) % 60
      
      const text = `👤 <b>Твой профиль</b>\n\n` +
        `📝 Имя: ${stats.first_name || stats.username || 'Не указано'}\n` +
        `👤 Username: @${stats.username || 'не указан'}\n\n` +
        `📊 <b>Статистика:</b>\n` +
        `🎬 Фильмов просмотрено: ${stats.movies_watched || 0}\n` +
        `📺 Сериалов просмотрено: ${stats.series_watched || 0}\n` +
        `⏱️ Время просмотра: ${hours}ч ${minutes}мин\n` +
        `❤️ Любимый жанр: ${stats.favorite_genre || '—'}\n\n` +
        `📅 Регистрация: ${(stats.created_at || '').slice(0, 10)}`
      
      await tg('editMessageText', {
        chat_id: userId,
        message_id: cb.message?.message_id,
        text,
        parse_mode: 'HTML',
        reply_markup: backKeyboard()
      })
      await tg('answerCallbackQuery', { callback_query_id: cb.id })
      return
    }
    
    if (data === 'top_movies') {
      const res = await fetch(`${TMDB_BASE}/movie/top_rated?api_key=${TMDB_API_KEY}&language=ru&page=1`, { cache: 'no-store' })
      const data2 = await res.json()
      
      let text = "🌟 <b>Топ фильмов</b>\n\n"
      for (let i = 0; i < Math.min(10, (data2.results || []).length); i++) {
        const m = data2.results[i]
        text += `${i + 1}. <b>${m.title}</b> (${(m.release_date || '').slice(0, 4)})\n   ⭐ ${Math.round((m.vote_average || 0) * 10) / 10}\n\n`
      }
      
      await tg('editMessageText', {
        chat_id: userId,
        message_id: cb.message?.message_id,
        text,
        parse_mode: 'HTML',
        reply_markup: backKeyboard()
      })
      await tg('answerCallbackQuery', { callback_query_id: cb.id })
      return
    }
    
    if (data === 'top_series') {
      const res = await fetch(`${TMDB_BASE}/tv/top_rated?api_key=${TMDB_API_KEY}&language=ru&page=1`, { cache: 'no-store' })
      const data2 = await res.json()
      
      let text = "📺 <b>Топ сериалов</b>\n\n"
      for (let i = 0; i < Math.min(10, (data2.results || []).length); i++) {
        const m = data2.results[i]
        text += `${i + 1}. <b>${m.name}</b> (${(m.first_air_date || '').slice(0, 4)})\n   ⭐ ${Math.round((m.vote_average || 0) * 10) / 10}\n\n`
      }
      
      await tg('editMessageText', {
        chat_id: userId,
        message_id: cb.message?.message_id,
        text,
        parse_mode: 'HTML',
        reply_markup: backKeyboard()
      })
      await tg('answerCallbackQuery', { callback_query_id: cb.id })
      return
    }
    
    if (data.startsWith('admin_')) {
      if (userId !== ADMIN_ID) {
        await tg('answerCallbackQuery', { callback_query_id: cb.id, text: "⛔ Нет доступа", show_alert: true })
        return
      }
      
      const action = data.replace('admin_', '')
      const totalUsers = await getTotalUsers()
      
      if (action === 'stats') {
        const storage = await getStorage()
        const todayUsers = Object.values(storage.users).filter((u: any) => 
          u.created_at && u.created_at.startsWith(new Date().toISOString().slice(0, 10))
        ).length
        
        await tg('editMessageText', {
          chat_id: userId,
          message_id: cb.message?.message_id,
          text: `📊 <b>Статистика</b>\n\n👥 Всего пользователей: ${totalUsers}\n📅 Новых сегодня: ${todayUsers}\n💾 Хранилище: JSON Blob`,
          parse_mode: 'HTML',
          reply_markup: adminKeyboard()
        })
      } else if (action === 'users') {
        const storage = await getStorage()
        const users = Object.values(storage.users).slice(0, 20) as any[]
        let text = `👥 <b>Пользователи</b> (всего: ${totalUsers}):\n\n`
        for (const u of users) {
          text += `✅ ${u.first_name || '—'} (@${u.username || '—'})\n`
        }
        if (totalUsers > 20) text += `\n... и ещё ${totalUsers - 20}`
        
        await tg('editMessageText', {
          chat_id: userId,
          message_id: cb.message?.message_id,
          text,
          parse_mode: 'HTML',
          reply_markup: adminKeyboard()
        })
      } else if (action === 'export') {
        const storage = await getStorage()
        const ids = Object.keys(storage.users).join('\n')
        await tg('sendMessage', {
          chat_id: userId,
          text: `📋 ID пользователей (${totalUsers}):\n\n<code>${ids}</code>`,
          parse_mode: 'HTML'
        })
      } else if (action === 'broadcast') {
        adminStates.set(userId, { action: 'awaiting_broadcast' })
        await tg('editMessageText', {
          chat_id: userId,
          message_id: cb.message?.message_id,
          text: `📢 <b>Рассылка</b>\n\nНапишите сообщение для рассылки всем пользователям (${totalUsers} чел.):\n\nПоддерживается HTML-форматирование:\n• <b>жирный</b>\n• <i>курсив</i>\n• <a href="url">ссылка</a>`,
          parse_mode: 'HTML'
        })
      } else if (action === 'broadcast_confirm') {
        const state = adminStates.get(userId)
        if (state && state.data?.message) {
          await tg('editMessageText', {
            chat_id: userId,
            message_id: cb.message?.message_id,
            text: `📢 <b>Отправка рассылки...</b>`,
            parse_mode: 'HTML'
          })
          await broadcastMessage(state.data.message, userId)
          adminStates.delete(userId)
        } else {
          await tg('editMessageText', {
            chat_id: userId,
            message_id: cb.message?.message_id,
            text: `❌ Ошибка: сообщение не найдено. Попробуйте заново.`,
            parse_mode: 'HTML',
            reply_markup: adminKeyboard()
          })
        }
      } else if (action === 'broadcast_cancel') {
        adminStates.delete(userId)
        await tg('editMessageText', {
          chat_id: userId,
          message_id: cb.message?.message_id,
          text: `❌ Рассылка отменена.`,
          parse_mode: 'HTML',
          reply_markup: adminKeyboard()
        })
      } else if (action === 'sync') {
        const storage = await getStorage()
        const actualCount = Object.keys(storage.users).length
        storage.total_users = actualCount
        await saveStorage(storage)
        
        await tg('editMessageText', {
          chat_id: userId,
          message_id: cb.message?.message_id,
          text: `✅ <b>Синхронизация завершена</b>\n\n👥 Пользователей: ${actualCount}`,
          parse_mode: 'HTML',
          reply_markup: adminKeyboard()
        })
      }
      
      await tg('answerCallbackQuery', { callback_query_id: cb.id })
      return
    }
  }
}

export async function POST(req: NextRequest) {
  try {
    const update = await req.json()
    console.log('[WEBHOOK] Received:', JSON.stringify(update).slice(0, 300))
    await handleUpdate(update)
    return NextResponse.json({ ok: true })
  } catch (error) {
    console.error('[WEBHOOK ERROR]:', error)
    return NextResponse.json({ ok: true })
  }
}

export async function GET() {
  const totalUsers = await getTotalUsers()
  
  return NextResponse.json({ 
    status: 'ok', 
    bot: 'KinoMir Bot',
    webhook: 'active',
    timestamp: Date.now(),
    version: '4.0',
    storage: 'jsonblob',
    total_users: totalUsers
  })
}

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
