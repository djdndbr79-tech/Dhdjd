import { NextResponse } from 'next/server'

const BOT_TOKEN = "8590904457:AAH508WQwV3a1TdEHh_jtUYGHM86Mpw-Q_I"
const ADMIN_ID = 8030989657

export async function GET() {
  try {
    // Test sending a message
    const testResult = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: ADMIN_ID,
        text: `🧪 Test message from API\n\nTime: ${new Date().toISOString()}\nWebhook should be working!`,
        parse_mode: 'HTML'
      })
    }).then(r => r.json())
    
    // Get webhook info
    const webhookInfo = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/getWebhookInfo`)
      .then(r => r.json())
    
    // Get me
    const botInfo = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/getMe`)
      .then(r => r.json())
    
    return NextResponse.json({
      success: true,
      testMessage: testResult,
      webhookInfo: webhookInfo,
      botInfo: botInfo,
      serverTime: new Date().toISOString()
    })
  } catch (error: any) {
    return NextResponse.json({
      success: false,
      error: error.message
    }, { status: 500 })
  }
}

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
