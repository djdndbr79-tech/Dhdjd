import { NextRequest, NextResponse } from 'next/server'

const TMDB_API_KEY = '2dca580c2a14b55200e784d157207b4d'
const TMDB_BASE = 'https://api.themoviedb.org/3'
const TMDB_IMAGE = 'https://image.tmdb.org/t/p/w500'

// Timeout for fetch requests
const FETCH_TIMEOUT = 10000

async function fetchWithTimeout(url: string, timeout: number = FETCH_TIMEOUT) {
  const controller = new AbortController()
  const timeoutId = setTimeout(() => controller.abort(), timeout)
  
  try {
    const response = await fetch(url, { signal: controller.signal })
    clearTimeout(timeoutId)
    return response
  } catch (error) {
    clearTimeout(timeoutId)
    throw error
  }
}

const movieGenres: Record<number, string> = {
  28: 'Боевик', 12: 'Приключения', 16: 'Мультфильм', 35: 'Комедия',
  80: 'Криминал', 99: 'Документальный', 18: 'Драма', 10751: 'Семейный',
  14: 'Фэнтези', 36: 'История', 27: 'Ужасы', 10402: 'Музыка',
  9648: 'Детектив', 10749: 'Мелодрама', 878: 'Фантастика', 10770: 'Телевизионный',
  53: 'Триллер', 10752: 'Военный', 37: 'Вестерн'
}

const tvGenres: Record<number, string> = {
  10759: 'Боевик', 16: 'Мультфильм', 35: 'Комедия',
  80: 'Криминал', 99: 'Документальный', 18: 'Драма', 10751: 'Семейный',
  10762: 'Детский', 9648: 'Детектив', 10765: 'Фантастика', 37: 'Вестерн'
}

// Cache
const cache = new Map<string, { data: any; timestamp: number }>()
const CACHE_DURATION = 5 * 60 * 1000 // 5 minutes

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const query = searchParams.get('q')
  
  if (!query) {
    return NextResponse.json({
      success: true,
      results: [],
      genres: Object.entries({ ...movieGenres, ...tvGenres }).map(([id, name]) => ({
        id: parseInt(id),
        name
      }))
    })
  }

  const cacheKey = `search_${query.toLowerCase()}`
  const cached = cache.get(cacheKey)
  if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
    return NextResponse.json(cached.data)
  }

  try {
    // Use multi search for better results - searches movies, TV shows, and people
    // Search MULTIPLE pages for MORE results
    const pages = [1, 2, 3]
    
    const allRequests = pages.flatMap(p => [
      // Multi search - finds everything
      fetchWithTimeout(`${TMDB_BASE}/search/multi?api_key=${TMDB_API_KEY}&language=ru&query=${encodeURIComponent(query)}&page=${p}&include_adult=false`).then(r => r.json()).catch(() => ({ results: [] })),
      // Dedicated movie search with more results
      fetchWithTimeout(`${TMDB_BASE}/search/movie?api_key=${TMDB_API_KEY}&language=ru&query=${encodeURIComponent(query)}&page=${p}&include_adult=false`).then(r => r.json()).catch(() => ({ results: [] })),
      // Dedicated TV search with more results
      fetchWithTimeout(`${TMDB_BASE}/search/tv?api_key=${TMDB_API_KEY}&language=ru&query=${encodeURIComponent(query)}&page=${p}&include_adult=false`).then(r => r.json()).catch(() => ({ results: [] }))
    ])

    const results = await Promise.all(allRequests)
    
    // Process all results
    const multiResults: any[] = []
    const seenIds = new Set<string>()
    
    // Process all responses
    for (const res of results) {
      if (!res?.results) continue
      
      for (const item of res.results) {
        // Handle movie results
        if (item.media_type === 'movie' || item.title) {
          const id = `movie_${item.id}`
          if (!seenIds.has(id)) {
            seenIds.add(id)
            multiResults.push({
              id: item.id.toString(),
              title: item.title || item.name,
              originalTitle: item.original_title || item.original_name,
              poster: item.poster_path ? `${TMDB_IMAGE}${item.poster_path}` : null,
              backdrop: item.backdrop_path ? `https://image.tmdb.org/t/p/original${item.backdrop_path}` : null,
              year: (item.release_date || item.first_air_date)?.split('-')[0] || '',
              rating: Math.round((item.vote_average || 0) * 10) / 10,
              votes: item.vote_count || 0,
              popularity: item.popularity || 0,
              genres: (item.genre_ids || []).map((id: number) => movieGenres[id] || tvGenres[id]).filter(Boolean),
              description: item.overview,
              type: 'movie'
            })
          }
        }
        // Handle TV results
        else if (item.media_type === 'tv' || item.name) {
          const id = `tv_${item.id}`
          if (!seenIds.has(id)) {
            seenIds.add(id)
            multiResults.push({
              id: item.id.toString(),
              title: item.name || item.title,
              originalTitle: item.original_name || item.original_title,
              poster: item.poster_path ? `${TMDB_IMAGE}${item.poster_path}` : null,
              backdrop: item.backdrop_path ? `https://image.tmdb.org/t/p/original${item.backdrop_path}` : null,
              year: (item.first_air_date || item.release_date)?.split('-')[0] || '',
              rating: Math.round((item.vote_average || 0) * 10) / 10,
              votes: item.vote_count || 0,
              popularity: item.popularity || 0,
              genres: (item.genre_ids || []).map((id: number) => tvGenres[id] || movieGenres[id]).filter(Boolean),
              description: item.overview,
              type: 'tv'
            })
          }
        }
      }
    }

    // Sort by relevance: title match > popularity > rating
    const queryLower = query.toLowerCase()
    const sortedResults = multiResults.sort((a, b) => {
      // Prioritize title starts with query
      const aStarts = a.title.toLowerCase().startsWith(queryLower) ? 1 : 0
      const bStarts = b.title.toLowerCase().startsWith(queryLower) ? 1 : 0
      if (aStarts !== bStarts) return bStarts - aStarts
      
      // Then by title contains query
      const aContains = a.title.toLowerCase().includes(queryLower) ? 1 : 0
      const bContains = b.title.toLowerCase().includes(queryLower) ? 1 : 0
      if (aContains !== bContains) return bContains - aContains
      
      // Then by popularity
      return (b.popularity || 0) - (a.popularity || 0)
    }).slice(0, 30) // Limit to 30 results

    const response = {
      success: true,
      results: sortedResults,
      query,
      total: sortedResults.length
    }

    cache.set(cacheKey, { data: response, timestamp: Date.now() })
    return NextResponse.json(response)

  } catch (error) {
    console.error('Search error:', error)
    return NextResponse.json({
      success: false,
      results: [],
      error: 'Search failed'
    }, { status: 500 })
  }
}
