import { NextRequest, NextResponse } from 'next/server'

// Simple in-memory database (use Prisma/SQLite for production)
const usersDB = new Map<string, {
  id: string
  telegramId: number
  username?: string
  firstName?: string
  lastName?: string
  photoUrl?: string
  moviesWatched: number
  seriesWatched: number
  favoriteGenre: string
  currentlyWatching?: { title: string; type: string; poster: string }
  watchTime: number
  createdAt: string
  updatedAt: string
  isBanned: boolean
}>()

// Genres tracking for favorite genre
const userGenres = new Map<string, Map<string, number>>()

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { telegramId, username, firstName, lastName, photoUrl } = body
    
    if (!telegramId) {
      return NextResponse.json({ success: false, error: 'Telegram ID required' }, { status: 400 })
    }
    
    const userId = `tg_${telegramId}`
    const existingUser = usersDB.get(userId)
    
    if (existingUser) {
      // Update user info
      const updated = {
        ...existingUser,
        username: username || existingUser.username,
        firstName: firstName || existingUser.firstName,
        lastName: lastName || existingUser.lastName,
        photoUrl: photoUrl || existingUser.photoUrl,
        updatedAt: new Date().toISOString()
      }
      usersDB.set(userId, updated)
      
      return NextResponse.json({ success: true, profile: updated })
    }
    
    // Create new user
    const newUser = {
      id: userId,
      telegramId,
      username,
      firstName,
      lastName,
      photoUrl,
      moviesWatched: 0,
      seriesWatched: 0,
      favoriteGenre: '—',
      watchTime: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      isBanned: false
    }
    
    usersDB.set(userId, newUser)
    userGenres.set(userId, new Map())
    
    return NextResponse.json({ success: true, profile: newUser, isNew: true })
    
  } catch (error) {
    console.error('Profile error:', error)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const telegramId = searchParams.get('telegramId')
  
  if (!telegramId) {
    return NextResponse.json({ success: false, error: 'Telegram ID required' }, { status: 400 })
  }
  
  const userId = `tg_${telegramId}`
  const user = usersDB.get(userId)
  
  if (!user) {
    return NextResponse.json({ success: false, error: 'User not found' }, { status: 404 })
  }
  
  return NextResponse.json({ success: true, profile: user })
}

// Export for use in other API routes
export { usersDB, userGenres }
