import { NextRequest, NextResponse } from 'next/server'
import { usersDB, userGenres } from '../route'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { telegramId, movieId, type, title, poster, genres } = body
    
    if (!telegramId) {
      return NextResponse.json({ success: false, error: 'Telegram ID required' }, { status: 400 })
    }
    
    const userId = `tg_${telegramId}`
    const user = usersDB.get(userId)
    
    if (!user) {
      return NextResponse.json({ success: false, error: 'User not found' }, { status: 404 })
    }
    
    // Update watch stats
    if (type === 'movie') {
      user.moviesWatched++
    } else {
      user.seriesWatched++
    }
    
    // Update currently watching
    if (title && poster) {
      user.currentlyWatching = { title, type, poster }
    }
    
    // Track genres for favorite
    if (genres && genres.length > 0) {
      let genreMap = userGenres.get(userId)
      if (!genreMap) {
        genreMap = new Map()
        userGenres.set(userId, genreMap)
      }
      
      genres.forEach((genre: string) => {
        genreMap!.set(genre, (genreMap!.get(genre) || 0) + 1)
      })
      
      // Find most watched genre
      let maxCount = 0
      let favGenre = user.favoriteGenre
      genreMap.forEach((count, genre) => {
        if (count > maxCount) {
          maxCount = count
          favGenre = genre
        }
      })
      user.favoriteGenre = favGenre
    }
    
    user.watchTime += 30 // Approximate minutes per watch
    user.updatedAt = new Date().toISOString()
    
    usersDB.set(userId, user)
    
    return NextResponse.json({ success: true, profile: user })
    
  } catch (error) {
    console.error('Watch tracking error:', error)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}
