import { NextRequest, NextResponse } from 'next/server'

// TMDB API - бесплатный и открытый
const TMDB_API_KEY = '2dca580c2a14b55200e784d157207b4d'
const TMDB_BASE = 'https://api.themoviedb.org/3'
const TMDB_IMAGE = 'https://image.tmdb.org/t/p/w500'

interface TMDBMovie {
  id: number
  title: string
  original_title: string
  poster_path: string | null
  backdrop_path: string | null
  overview: string
  release_date: string
  vote_average: number
  vote_count: number
  popularity: number
  genre_ids: number[]
  adult: boolean
}

interface TMDBTV {
  id: number
  name: string
  original_name: string
  poster_path: string | null
  backdrop_path: string | null
  overview: string
  first_air_date: string
  vote_average: number
  vote_count: number
  popularity: number
  genre_ids: number[]
}

// Genre mappings
const movieGenres: Record<number, string> = {
  28: 'Боевик', 12: 'Приключения', 16: 'Мультфильм', 35: 'Комедия',
  80: 'Криминал', 99: 'Документальный', 18: 'Драма', 10751: 'Семейный',
  14: 'Фэнтези', 36: 'История', 27: 'Ужасы', 10402: 'Музыка',
  9648: 'Детектив', 10749: 'Мелодрама', 878: 'Фантастика', 10770: 'Телевизионный',
  53: 'Триллер', 10752: 'Военный', 37: 'Вестерн'
}

const tvGenres: Record<number, string> = {
  10759: 'Боевик и Приключения', 16: 'Мультфильм', 35: 'Комедия',
  80: 'Криминал', 99: 'Документальный', 18: 'Драма', 10751: 'Семейный',
  10762: 'Детский', 9648: 'Детектив', 10763: 'Новости',
  10764: 'Реалити-шоу', 10765: 'Фантастика', 10766: 'Мыльная опера',
  10767: 'Ток-шоу', 10768: 'Военный', 37: 'Вестерн'
}

function formatMovie(movie: TMDBMovie) {
  return {
    id: movie.id.toString(),
    title: movie.title,
    originalTitle: movie.original_title,
    poster: movie.poster_path ? `${TMDB_IMAGE}${movie.poster_path}` : '/placeholder.jpg',
    backdrop: movie.backdrop_path ? `https://image.tmdb.org/t/p/original${movie.backdrop_path}` : null,
    year: movie.release_date?.split('-')[0] || '',
    rating: Math.round(movie.vote_average * 10) / 10,
    votes: movie.vote_count,
    popularity: movie.popularity,
    genres: movie.genre_ids.map(id => movieGenres[id]).filter(Boolean),
    description: movie.overview,
    type: 'movie'
  }
}

function formatTV(show: TMDBTV) {
  return {
    id: show.id.toString(),
    title: show.name,
    originalTitle: show.original_name,
    poster: show.poster_path ? `${TMDB_IMAGE}${show.poster_path}` : '/placeholder.jpg',
    backdrop: show.backdrop_path ? `https://image.tmdb.org/t/p/original${show.backdrop_path}` : null,
    year: show.first_air_date?.split('-')[0] || '',
    rating: Math.round(show.vote_average * 10) / 10,
    votes: show.vote_count,
    popularity: show.popularity,
    genres: show.genre_ids.map(id => tvGenres[id]).filter(Boolean),
    description: show.overview,
    type: 'tv'
  }
}

// Cache
const cache = new Map<string, { data: any; timestamp: number }>()
const CACHE_DURATION = 5 * 60 * 1000 // 5 minutes

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const type = searchParams.get('type') || 'all'
  const page = searchParams.get('page') || '1'
  
  const cacheKey = `home_${type}_${page}`
  const cached = cache.get(cacheKey)
  if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
    return NextResponse.json(cached.data)
  }

  try {
    // Fetch from MULTIPLE pages to get MORE content
    const pages = [1, 2, 3, 4, 5]
    
    const allRequests = pages.flatMap(p => [
      // Movies
      fetch(`${TMDB_BASE}/trending/movie/week?api_key=${TMDB_API_KEY}&language=ru&page=${p}`).then(r => r.json()),
      fetch(`${TMDB_BASE}/movie/popular?api_key=${TMDB_API_KEY}&language=ru&page=${p}`).then(r => r.json()),
      fetch(`${TMDB_BASE}/movie/top_rated?api_key=${TMDB_API_KEY}&language=ru&page=${p}`).then(r => r.json()),
      fetch(`${TMDB_BASE}/movie/now_playing?api_key=${TMDB_API_KEY}&language=ru&page=${p}`).then(r => r.json()),
      fetch(`${TMDB_BASE}/movie/upcoming?api_key=${TMDB_API_KEY}&language=ru&page=${p}`).then(r => r.json()),
      // TV Shows - MANY MORE
      fetch(`${TMDB_BASE}/trending/tv/week?api_key=${TMDB_API_KEY}&language=ru&page=${p}`).then(r => r.json()),
      fetch(`${TMDB_BASE}/tv/popular?api_key=${TMDB_API_KEY}&language=ru&page=${p}`).then(r => r.json()),
      fetch(`${TMDB_BASE}/tv/top_rated?api_key=${TMDB_API_KEY}&language=ru&page=${p}`).then(r => r.json()),
      fetch(`${TMDB_BASE}/tv/on_the_air?api_key=${TMDB_API_KEY}&language=ru&page=${p}`).then(r => r.json()),
      fetch(`${TMDB_BASE}/tv/airing_today?api_key=${TMDB_API_KEY}&language=ru&page=${p}`).then(r => r.json()),
      // Discover more content
      fetch(`${TMDB_BASE}/discover/movie?api_key=${TMDB_API_KEY}&language=ru&page=${p}&sort_by=popularity.desc`).then(r => r.json()),
      fetch(`${TMDB_BASE}/discover/tv?api_key=${TMDB_API_KEY}&language=ru&page=${p}&sort_by=popularity.desc`).then(r => r.json()),
    ])
    
    const results = await Promise.all(allRequests)
    
    // Parse all results
    let idx = 0
    const allMovies: any[] = []
    const allTV: any[] = []
    
    pages.forEach(() => {
      // Movies - trending, popular, top_rated, now_playing, upcoming
      for (let i = 0; i < 5; i++) {
        const data = results[idx++]
        if (data?.results) {
          allMovies.push(...data.results.map(formatMovie))
        }
      }
      // TV - trending, popular, top_rated, on_the_air, airing_today
      for (let i = 0; i < 5; i++) {
        const data = results[idx++]
        if (data?.results) {
          allTV.push(...data.results.map(formatTV))
        }
      }
      // Discover
      const discoverMovies = results[idx++]
      const discoverTV = results[idx++]
      if (discoverMovies?.results) {
        allMovies.push(...discoverMovies.results.map(formatMovie))
      }
      if (discoverTV?.results) {
        allTV.push(...discoverTV.results.map(formatTV))
      }
    })
    
    // Remove duplicates by ID
    const uniqueMovies = Array.from(
      new Map(allMovies.map(m => [m.id, m])).values()
    ).sort((a, b) => (b.popularity || 0) - (a.popularity || 0))
    
    const uniqueTV = Array.from(
      new Map(allTV.map(t => [t.id, t])).values()
    ).sort((a, b) => (b.popularity || 0) - (a.popularity || 0))
    
    // Combine trending
    const trending = [...uniqueMovies.slice(0, 15), ...uniqueTV.slice(0, 15)]
    
    // Top rated
    const topRated = uniqueMovies
      .filter(m => m.rating >= 7)
      .slice(0, 20)
    
    // Now playing
    const nowPlaying = uniqueMovies.slice(0, 20)
    
    // Popular TV - MUCH MORE
    const popularTV = uniqueTV.slice(0, 50)

    const response = {
      success: true,
      trending,
      topRated,
      nowPlaying,
      popular: uniqueMovies.slice(0, 50),
      popularTV,
      content: type === 'tv' ? uniqueTV.slice(0, 100) : 
               type === 'movies' ? uniqueMovies.slice(0, 100) : 
               [...uniqueMovies.slice(0, 50), ...uniqueTV.slice(0, 50)],
      totalMovies: uniqueMovies.length,
      totalTV: uniqueTV.length,
      source: 'tmdb'
    }

    cache.set(cacheKey, { data: response, timestamp: Date.now() })
    return NextResponse.json(response)

  } catch (error) {
    console.error('TMDB fetch error:', error)
    return NextResponse.json({
      success: false,
      error: 'Failed to fetch content',
      message: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 })
  }
}
