import { NextRequest, NextResponse } from 'next/server'

const TMDB_API_KEY = '2dca580c2a14b55200e784d157207b4d'
const TMDB_BASE = 'https://api.themoviedb.org/3'
const TMDB_IMAGE = 'https://image.tmdb.org/t/p/w500'

const movieGenres: Record<number, string> = {
  28: 'Боевик', 12: 'Приключения', 16: 'Мультфильм', 35: 'Комедия',
  80: 'Криминал', 99: 'Документальный', 18: 'Драма', 10751: 'Семейный',
  14: 'Фэнтези', 36: 'История', 27: 'Ужасы', 10402: 'Музыка',
  9648: 'Детектив', 10749: 'Мелодрама', 878: 'Фантастика', 10770: 'Телевизионный',
  53: 'Триллер', 10752: 'Военный', 37: 'Вестерн'
}

const tvGenres: Record<number, string> = {
  10759: 'Боевик', 16: 'Мультфильм', 35: 'Комедия',
  80: 'Криминал', 99: 'Документальный', 18: 'Драма', 10751: 'Семейный',
  10762: 'Детский', 9648: 'Детектив', 10765: 'Фантастика', 37: 'Вестерн'
}

// Working player URLs with quality info - CLEAN SOURCES ONLY
function getPlayers(id: string, type: string, imdbId?: string, season?: number, episode?: number) {
  const players = []
  const s = season || 1
  const e = episode || 1
  
  // Atomics.ws - BEST PLAYER with IMDB ID
  if (imdbId) {
    players.push({
      name: 'Atomics',
      url: `https://api.atomics.ws/embed/imdb/${imdbId}`,
      quality: '1080p',
      maxQuality: '1080p'
    })
    if (type === 'tv') {
      players.push({
        name: 'Atomics TV',
        url: `https://api.atomics.ws/embed/imdb/${imdbId}/${s}/${e}`,
        quality: '1080p',
        maxQuality: '1080p'
      })
    }
  }
  
  if (type === 'movie') {
    // Clean players only - no ads
    players.push({
      name: 'EmbedSu',
      url: `https://embed.su/embed/movie/${id}`,
      quality: '4K',
      maxQuality: '4K'
    })
    players.push({
      name: 'VidSrc Pro',
      url: `https://vidsrc.pro/embed/movie/${id}`,
      quality: '1080p',
      maxQuality: '1080p'
    })
    players.push({
      name: 'VidSrc.cc',
      url: `https://vidsrc.cc/v2/embed/movie/${id}`,
      quality: '1080p',
      maxQuality: '1080p'
    })
    players.push({
      name: 'AutoEmbed',
      url: `https://autoembed.cc/embed/movie/${id}`,
      quality: '1080p',
      maxQuality: '1080p'
    })
    players.push({
      name: 'SuperEmbed',
      url: `https://multiembed.mov/?video_id=${id}&tmdb=1`,
      quality: '1080p',
      maxQuality: '1080p'
    })
  } else {
    // TV series players - clean sources only
    players.push({
      name: 'EmbedSu',
      url: `https://embed.su/embed/tv/${id}/${s}/${e}`,
      quality: '4K',
      maxQuality: '4K'
    })
    players.push({
      name: 'VidSrc Pro',
      url: `https://vidsrc.pro/embed/tv/${id}/${s}/${e}`,
      quality: '1080p',
      maxQuality: '1080p'
    })
    players.push({
      name: 'VidSrc.cc',
      url: `https://vidsrc.cc/v2/embed/tv/${id}/${s}/${e}`,
      quality: '1080p',
      maxQuality: '1080p'
    })
    players.push({
      name: 'AutoEmbed',
      url: `https://autoembed.cc/embed/tv/${id}/${s}/${e}`,
      quality: '1080p',
      maxQuality: '1080p'
    })
    players.push({
      name: 'SuperEmbed',
      url: `https://multiembed.mov/?video_id=${id}&tmdb=1&s=${s}&e=${e}`,
      quality: '1080p',
      maxQuality: '1080p'
    })
  }
  
  return players
}

// Cache
const cache = new Map<string, { data: any; timestamp: number }>()
const CACHE_DURATION = 30 * 60 * 1000 // 30 minutes

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const id = searchParams.get('id')
  const type = searchParams.get('type') || 'movie'
  const season = searchParams.get('season')
  const episode = searchParams.get('episode')
  
  if (!id) {
    return NextResponse.json({
      success: false,
      error: 'ID is required'
    }, { status: 400 })
  }

  const cacheKey = `movie_${id}_${type}_${season || 1}_${episode || 1}`
  const cached = cache.get(cacheKey)
  if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
    return NextResponse.json(cached.data)
  }

  try {
    let details: any
    let credits: any
    let videos: any
    let similar: any
    let seasons: any[] = []
    let releaseDates: any

    if (type === 'movie') {
      [details, credits, videos, similar, releaseDates] = await Promise.all([
        fetch(`${TMDB_BASE}/movie/${id}?api_key=${TMDB_API_KEY}&language=ru`).then(r => r.json()),
        fetch(`${TMDB_BASE}/movie/${id}/credits?api_key=${TMDB_API_KEY}`).then(r => r.json()),
        fetch(`${TMDB_BASE}/movie/${id}/videos?api_key=${TMDB_API_KEY}`).then(r => r.json()),
        fetch(`${TMDB_BASE}/movie/${id}/similar?api_key=${TMDB_API_KEY}&language=ru`).then(r => r.json()),
        fetch(`${TMDB_BASE}/movie/${id}/release_dates?api_key=${TMDB_API_KEY}`).then(r => r.json()).catch(() => null)
      ])
    } else {
      [details, credits, videos, similar] = await Promise.all([
        fetch(`${TMDB_BASE}/tv/${id}?api_key=${TMDB_API_KEY}&language=ru`).then(r => r.json()),
        fetch(`${TMDB_BASE}/tv/${id}/credits?api_key=${TMDB_API_KEY}`).then(r => r.json()),
        fetch(`${TMDB_BASE}/tv/${id}/videos?api_key=${TMDB_API_KEY}`).then(r => r.json()),
        fetch(`${TMDB_BASE}/tv/${id}/similar?api_key=${TMDB_API_KEY}&language=ru`).then(r => r.json())
      ])
      
      seasons = (details.seasons || []).map((s: any) => ({
        seasonNumber: s.season_number,
        name: s.name,
        episodeCount: s.episode_count,
        poster: s.poster_path ? `${TMDB_IMAGE}${s.poster_path}` : null
      }))
    }

    // Get trailer
    const trailer = (videos.results || []).find(
      (v: any) => v.type === 'Trailer' && v.site === 'YouTube'
    )

    // Determine max available quality
    let maxQuality = '1080p'
    if (details.vote_average >= 7.5 && details.popularity > 100) {
      maxQuality = '4K'
    } else if (details.vote_average < 6 || details.popularity < 10) {
      maxQuality = '720p'
    }

    const result = {
      success: true,
      movie: {
        id: id,
        imdbId: details.imdb_id || null,
        title: type === 'movie' ? details.title : details.name,
        originalTitle: type === 'movie' ? details.original_title : details.original_name,
        poster: details.poster_path ? `${TMDB_IMAGE}${details.poster_path}` : null,
        backdrop: details.backdrop_path ? `https://image.tmdb.org/t/p/original${details.backdrop_path}` : null,
        year: (type === 'movie' ? details.release_date : details.first_air_date)?.split('-')[0] || '',
        rating: Math.round(details.vote_average * 10) / 10,
        votes: details.vote_count,
        runtime: details.runtime || details.episode_run_time?.[0],
        genres: (details.genres || []).map((g: any) => g.name),
        overview: details.overview,
        tagline: details.tagline,
        status: details.status,
        budget: details.budget,
        revenue: details.revenue,
        country: (details.production_countries || [])?.[0]?.name,
        director: (credits.crew || []).find((c: any) => c.job === 'Director')?.name,
        actors: (credits.cast || []).slice(0, 10).map((c: any) => ({
          name: c.name,
          character: c.character,
          photo: c.profile_path ? `${TMDB_IMAGE}${c.profile_path}` : null
        })),
        trailer: trailer ? `https://www.youtube.com/watch?v=${trailer.key}` : null,
        players: getPlayers(id, type, details.imdb_id, season ? parseInt(season) : 1, episode ? parseInt(episode) : 1),
        seasons: type === 'tv' ? seasons : undefined,
        currentSeason: season ? parseInt(season) : 1,
        currentEpisode: episode ? parseInt(episode) : 1,
        type: type,
        maxQuality: maxQuality,
        popularity: details.popularity
      }
    }

    cache.set(cacheKey, { data: result, timestamp: Date.now() })
    return NextResponse.json(result)

  } catch (error) {
    console.error('Details fetch error:', error)
    return NextResponse.json({
      success: false,
      error: 'Failed to fetch details'
    }, { status: 500 })
  }
}
