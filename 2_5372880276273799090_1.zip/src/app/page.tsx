'use client'

import { useState, useEffect, useCallback, useMemo, memo, useRef } from 'react'
import { 
  Search, Film, Tv, Menu, X, Heart, Share2, 
  ArrowLeft, Clock, Star, Play,
  Sparkles, Trash2, ChevronDown, Monitor, Settings,
  XCircle, User, Eye, AlertTriangle
} from 'lucide-react'

// Types
interface Movie {
  id: string
  title: string
  originalTitle?: string
  poster: string | null
  backdrop?: string | null
  year: string
  rating: number
  votes?: number
  genres: string[]
  description?: string
  type: 'movie' | 'tv'
}

interface UserProfile {
  id: string
  telegramId: number
  username?: string
  firstName?: string
  lastName?: string
  photoUrl?: string
  moviesWatched: number
  seriesWatched: number
  favoriteGenre: string
  currentlyWatching?: {
    title: string
    type: string
    poster: string
  }
  watchTime: number
  createdAt: string
}

// Update profile when watching
const updateProfileOnWatch = (movie: Movie, genres: string[] = []) => {
  if (typeof window === 'undefined') return
  
  const saved = localStorage.getItem(PROFILE_KEY)
  if (!saved) return
  
  try {
    const profile = JSON.parse(saved)
    
    // Update watch stats
    if (movie.type === 'movie') {
      profile.moviesWatched = (profile.moviesWatched || 0) + 1
    } else {
      profile.seriesWatched = (profile.seriesWatched || 0) + 1
    }
    
    // Update currently watching
    profile.currentlyWatching = {
      title: movie.title,
      type: movie.type,
      poster: movie.poster || ''
    }
    
    // Update watch time (approx 90 min per movie, 45 per episode)
    profile.watchTime = (profile.watchTime || 0) + (movie.type === 'movie' ? 90 : 45)
    
    // Track genres for favorite
    if (genres.length > 0) {
      const genreCounts: Record<string, number> = JSON.parse(localStorage.getItem('kinomir_genres') || '{}')
      genres.forEach(g => {
        genreCounts[g] = (genreCounts[g] || 0) + 1
      })
      localStorage.setItem('kinomir_genres', JSON.stringify(genreCounts))
      
      // Find most watched genre
      const sortedGenres = Object.entries(genreCounts).sort((a, b) => b[1] - a[1])
      if (sortedGenres.length > 0) {
        profile.favoriteGenre = sortedGenres[0][0]
      }
    }
    
    localStorage.setItem(PROFILE_KEY, JSON.stringify(profile))
    return profile
  } catch {}
  
  return null
}

interface MovieDetails extends Movie {
  runtime?: number
  tagline?: string
  country?: string
  director?: string
  actors?: { name: string; character: string; photo: string | null }[]
  trailer?: string
  players: { name: string; url: string; quality: string }[]
  seasons?: { seasonNumber: number; name: string; episodeCount: number }[]
  currentSeason?: number
  currentEpisode?: number
}

// Storage keys
const FAV_KEY = 'kinomir_favorites'
const PROFILE_KEY = 'kinomir_profile'
const HISTORY_KEY = 'kinomir_history'

// Get Telegram user data
const getTelegramUser = (): { id: number; username?: string; first_name?: string; last_name?: string; photo_url?: string } | null => {
  if (typeof window !== 'undefined' && (window as any).Telegram?.WebApp?.initDataUnsafe?.user) {
    return (window as any).Telegram.WebApp.initDataUnsafe.user
  }
  return null
}

// Storage helpers
const getFavorites = (): Movie[] => {
  if (typeof window === 'undefined') return []
  try {
    return JSON.parse(localStorage.getItem(FAV_KEY) || '[]')
  } catch { return [] }
}

const saveFavorites = (favs: Movie[]) => {
  localStorage.setItem(FAV_KEY, JSON.stringify(favs))
}

const getHistory = (): Movie[] => {
  if (typeof window === 'undefined') return []
  try {
    return JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]')
  } catch { return [] }
}

const addToHistory = (movie: Movie) => {
  const history = getHistory()
  const filtered = history.filter(m => m.id !== movie.id)
  const updated = [movie, ...filtered].slice(0, 50)
  localStorage.setItem(HISTORY_KEY, JSON.stringify(updated))
}

// Rating Badge
const RatingBadge = memo(function RatingBadge({ rating }: { rating: number }) {
  const colorClass = useMemo(() => {
    if (rating >= 7) return 'from-emerald-500 to-green-400'
    if (rating >= 5) return 'from-amber-500 to-yellow-400'
    return 'from-red-500 to-rose-400'
  }, [rating])
  
  return (
    <span className={`px-2 py-0.5 rounded-md text-[11px] font-bold text-white bg-gradient-to-r ${colorClass}`}>
      {rating.toFixed(1)}
    </span>
  )
})

// Movie Card
const MovieCard = memo(function MovieCard({ 
  movie, 
  onClick, 
  isFavorite, 
  onToggleFavorite 
}: { 
  movie: Movie
  onClick: () => void
  isFavorite: boolean
  onToggleFavorite: (e: React.MouseEvent) => void
}) {
  const [imgError, setImgError] = useState(false)
  
  return (
    <div
      className="movie-card relative flex-shrink-0 w-[140px] cursor-pointer"
      onClick={onClick}
    >
      <div className="relative aspect-[2/3] rounded-xl overflow-hidden bg-[#1a1a2e] neon-border">
        {!imgError && movie.poster ? (
          <img 
            src={movie.poster} 
            alt={movie.title}
            className="w-full h-full object-cover"
            loading="lazy"
            decoding="async"
            onError={() => setImgError(true)}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Film className="w-12 h-12 text-gray-600" />
          </div>
        )}
        
        {movie.rating > 0 && (
          <div className="absolute top-2 left-2">
            <RatingBadge rating={movie.rating} />
          </div>
        )}
        
        <button
          onClick={onToggleFavorite}
          className={`absolute top-2 right-2 p-1.5 rounded-full bg-black/60 backdrop-blur-sm transition-colors ${
            isFavorite ? 'text-[#ff2d92]' : 'text-white/60'
          }`}
        >
          <Heart className={`w-4 h-4 ${isFavorite ? 'fill-current' : ''}`} />
        </button>
        
        <div className="movie-card-overlay absolute inset-0 bg-black/60 flex items-center justify-center">
          <div className="w-14 h-14 rounded-full bg-gradient-to-br from-[#ff2d92] to-[#ff6eb4] flex items-center justify-center neon-glow">
            <Play className="w-6 h-6 text-white fill-white ml-1" />
          </div>
        </div>
        
        <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black/90 to-transparent">
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#ff2d92]/90 text-white font-medium">
            {movie.type === 'tv' ? 'Сериал' : 'Фильм'}
          </span>
        </div>
      </div>
      
      <div className="mt-2 px-0.5">
        <h3 className="text-sm font-medium text-white truncate">{movie.title}</h3>
        <div className="flex items-center gap-2 mt-0.5 text-xs text-gray-400">
          <span>{movie.year}</span>
          {movie.genres?.[0] && (
            <>
              <span className="text-[#ff2d92]">•</span>
              <span className="truncate">{movie.genres[0]}</span>
            </>
          )}
        </div>
      </div>
    </div>
  )
})

// Quality options
const QUALITY_OPTIONS = ['360p', '480p', '720p', '1080p', '4K']
const SPEED_OPTIONS = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 2]

// Video Player - fixed loading
const VideoPlayer = memo(function VideoPlayer({ 
  players, 
  title,
  onWatchStart,
}: { 
  players: { name: string; url: string; quality: string }[]
  title: string
  onWatchStart?: () => void
}) {
  const [currentPlayer, setCurrentPlayer] = useState(0)
  const [isLoading, setIsLoading] = useState(true)
  const [showSettings, setShowSettings] = useState(false)
  const [showAdWarning, setShowAdWarning] = useState(true)
  const [settingsTab, setSettingsTab] = useState<'quality' | 'speed'>('quality')
  const [selectedQuality, setSelectedQuality] = useState('1080p')
  const [selectedSpeed, setSelectedSpeed] = useState(1)
  const iframeRef = useRef<HTMLIFrameElement>(null)
  const settingsRef = useRef<HTMLDivElement>(null)
  const loadingTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  
  const player = players[currentPlayer]
  
  // Clear timeout on unmount
  useEffect(() => {
    return () => {
      if (loadingTimeoutRef.current) {
        clearTimeout(loadingTimeoutRef.current)
      }
    }
  }, [])
  
  // Auto-hide loading after iframe loads or timeout
  const handleIframeLoad = useCallback(() => {
    // Clear any existing timeout
    if (loadingTimeoutRef.current) {
      clearTimeout(loadingTimeoutRef.current)
    }
    
    // Hide loading after a short delay
    loadingTimeoutRef.current = setTimeout(() => {
      setIsLoading(false)
      onWatchStart?.()
    }, 500)
  }, [onWatchStart])
  
  // Set a maximum loading timeout
  useEffect(() => {
    if (isLoading) {
      loadingTimeoutRef.current = setTimeout(() => {
        setIsLoading(false)
      }, 8000) // Max 8 seconds loading
    }
    
    return () => {
      if (loadingTimeoutRef.current) {
        clearTimeout(loadingTimeoutRef.current)
      }
    }
  }, [isLoading, currentPlayer])
  
  // Close settings when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent | TouchEvent) => {
      if (settingsRef.current && !settingsRef.current.contains(e.target as Node)) {
        setShowSettings(false)
      }
    }
    
    if (showSettings) {
      setTimeout(() => {
        document.addEventListener('mousedown', handleClickOutside)
        document.addEventListener('touchstart', handleClickOutside)
      }, 100)
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
      document.removeEventListener('touchstart', handleClickOutside)
    }
  }, [showSettings])
  
  const handlePlayerChange = useCallback((index: number) => {
    // Clear any existing timeout
    if (loadingTimeoutRef.current) {
      clearTimeout(loadingTimeoutRef.current)
    }
    
    setCurrentPlayer(index)
    setIsLoading(true)
  }, [])
  
  const closeSettings = useCallback(() => {
    setShowSettings(false)
  }, [])
  
  if (!players || players.length === 0) {
    return (
      <div className="w-full aspect-video rounded-xl flex items-center justify-center bg-[#1a1a2e] neon-border">
        <div className="text-center">
          <Monitor className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <p className="text-gray-400">Плеер недоступен</p>
        </div>
      </div>
    )
  }

  return (
    <div className="w-full">
      {/* Player container */}
      <div className="relative w-full aspect-video rounded-xl overflow-hidden bg-black neon-border">
        <iframe
          ref={iframeRef}
          key={player.url}
          src={player.url}
          className="absolute inset-0 w-full h-full border-0"
          allowFullScreen
          allow="autoplay; fullscreen; picture-in-picture; encrypted-media; accelerometer; gyroscope"
          title={title}
          onLoad={handleIframeLoad}
        />
        
        {/* Loading overlay - simple and works */}
        {isLoading && (
          <div className="absolute inset-0 z-10 flex items-center justify-center bg-black">
            <div className="text-center">
              <div className="loading-spinner mx-auto mb-3" />
              <p className="text-gray-400 text-sm">Загрузка {player.name}...</p>
            </div>
          </div>
        )}
        
        {/* Ad Warning Overlay - compact */}
        {showAdWarning && (
          <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/80">
            <div className="mx-2 max-w-[280px] bg-[#1a1a2e]/95 rounded-xl p-4 neon-border text-center">
              <div className="flex items-center justify-center gap-2 mb-2">
                <AlertTriangle className="w-5 h-5 text-[#ff2d92]" />
                <span className="text-white font-bold text-sm">Внимание!</span>
              </div>
              <p className="text-gray-300 text-xs mb-3">
                Если появится реклама — <span className="text-[#ff2d92] font-bold">нажмите «Нет»</span>
              </p>
              <button
                onClick={() => setShowAdWarning(false)}
                className="w-full py-2 rounded-lg bg-gradient-to-r from-[#ff2d92] to-[#ff6eb4] text-white text-sm font-medium"
              >
                Понятно
              </button>
            </div>
          </div>
        )}
        
        {/* Settings button */}
        <button
          onClick={() => setShowSettings(!showSettings)}
          className="absolute top-3 right-3 z-20 p-2 bg-black/60 backdrop-blur-sm rounded-lg text-white/80 hover:text-white transition-colors"
        >
          <Settings className="w-5 h-5" />
        </button>
      </div>
      
      {/* Settings dropdown */}
      {showSettings && (
        <div 
          ref={settingsRef}
          className="relative z-30 mt-2 w-64 bg-[#1a1a2e] rounded-xl neon-border overflow-hidden shadow-2xl"
        >
          <div className="flex items-center justify-between px-4 py-3 border-b border-[#ff2d92]/20">
            <span className="text-white font-medium">Настройки</span>
            <button onClick={closeSettings} className="p-1 text-gray-400 hover:text-white">
              <XCircle className="w-5 h-5" />
            </button>
          </div>
          
          <div className="flex border-b border-[#ff2d92]/20">
            <button
              onClick={() => setSettingsTab('quality')}
              className={`flex-1 py-2.5 text-sm font-medium ${
                settingsTab === 'quality' ? 'text-[#ff2d92] border-b-2 border-[#ff2d92]' : 'text-gray-400'
              }`}
            >
              Качество
            </button>
            <button
              onClick={() => setSettingsTab('speed')}
              className={`flex-1 py-2.5 text-sm font-medium ${
                settingsTab === 'speed' ? 'text-[#ff2d92] border-b-2 border-[#ff2d92]' : 'text-gray-400'
              }`}
            >
              Скорость
            </button>
          </div>
          
          <div className="max-h-48 overflow-y-auto">
            {settingsTab === 'quality' ? (
              <div className="p-2">
                {QUALITY_OPTIONS.map(q => (
                  <button
                    key={q}
                    onClick={() => { setSelectedQuality(q); closeSettings(); }}
                    className={`w-full px-3 py-2.5 rounded-lg text-left text-sm ${
                      selectedQuality === q 
                        ? 'bg-[#ff2d92]/20 text-[#ff2d92]' 
                        : 'text-gray-300 hover:bg-white/5'
                    }`}
                  >
                    {q}
                    {q === '1080p' && <span className="text-xs text-gray-500 ml-2">(рекомендуется)</span>}
                  </button>
                ))}
              </div>
            ) : (
              <div className="p-2">
                {SPEED_OPTIONS.map(s => (
                  <button
                    key={s}
                    onClick={() => { setSelectedSpeed(s); closeSettings(); }}
                    className={`w-full px-3 py-2.5 rounded-lg text-left text-sm ${
                      selectedSpeed === s 
                        ? 'bg-[#ff2d92]/20 text-[#ff2d92]' 
                        : 'text-gray-300 hover:bg-white/5'
                    }`}
                  >
                    {s === 1 ? 'Нормальная' : `${s}x`}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
      
      {/* Player selector */}
      <div className="mt-3 flex flex-wrap gap-2 items-center">
        <span className="text-xs text-gray-400">Плеер:</span>
        {players.map((p, i) => (
          <button
            key={i}
            onClick={() => handlePlayerChange(i)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              currentPlayer === i 
                ? 'bg-gradient-to-r from-[#ff2d92] to-[#ff6eb4] text-white' 
                : 'bg-[#1a1a2e] text-gray-400 neon-border'
            }`}
          >
            {p.name}
            <span className="ml-1 text-[10px] opacity-70">{p.quality}</span>
          </button>
        ))}
      </div>
    </div>
  )
})

// Episode Selector
const EpisodeSelector = memo(function EpisodeSelector({
  seasons,
  currentSeason,
  currentEpisode,
  onSelect
}: {
  seasons: { seasonNumber: number; name: string; episodeCount: number }[]
  currentSeason: number
  currentEpisode: number
  onSelect: (season: number, episode: number) => void
}) {
  const [showSeasons, setShowSeasons] = useState(false)
  const season = seasons.find(s => s.seasonNumber === currentSeason)
  
  return (
    <div className="mt-4 space-y-3">
      <div className="relative">
        <button 
          onClick={() => setShowSeasons(!showSeasons)}
          className="w-full flex items-center justify-between px-4 py-3 bg-[#1a1a2e] rounded-xl neon-border"
        >
          <span className="text-white font-medium">{season?.name || `Сезон ${currentSeason}`}</span>
          <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform ${showSeasons ? 'rotate-180' : ''}`} />
        </button>
        
        {showSeasons && (
          <div className="absolute top-full left-0 right-0 mt-2 bg-[#1a1a2e] rounded-xl neon-border overflow-hidden z-20 max-h-60 overflow-y-auto">
            {seasons.map(s => (
              <button
                key={s.seasonNumber}
                onClick={() => { onSelect(s.seasonNumber, 1); setShowSeasons(false); }}
                className={`w-full px-4 py-3 text-left ${s.seasonNumber === currentSeason ? 'text-[#ff2d92]' : 'text-gray-300'}`}
              >
                {s.name}
                <span className="text-xs text-gray-500 ml-2">({s.episodeCount} эп.)</span>
              </button>
            ))}
          </div>
        )}
      </div>
      
      {season && (
        <div>
          <h4 className="text-sm text-gray-400 mb-2">Эпизоды</h4>
          <div className="grid grid-cols-5 gap-2">
            {Array.from({ length: season.episodeCount }, (_, i) => i + 1).map(ep => (
              <button
                key={ep}
                onClick={() => onSelect(currentSeason, ep)}
                className={`aspect-square rounded-lg text-sm font-medium ${
                  ep === currentEpisode
                    ? 'bg-gradient-to-br from-[#ff2d92] to-[#ff6eb4] text-white'
                    : 'bg-[#1a1a2e] text-gray-400 neon-border'
                }`}
              >
                {ep}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  )
})

// Sidebar
const Sidebar = memo(function Sidebar({ 
  isOpen, 
  onClose, 
  favorites, 
  onSelectMovie,
  onRemoveFavorite,
  onClearFavorites,
  profile
}: { 
  isOpen: boolean
  onClose: () => void
  favorites: Movie[]
  onSelectMovie: (movie: Movie) => void
  onRemoveFavorite: (id: string) => void
  onClearFavorites: () => void
  profile: UserProfile | null
}) {
  if (!isOpen) return null
  
  return (
    <>
      <div className="sidebar-overlay animate-fade-in" onClick={onClose} />
      <div className="sidebar animate-slide-in">
        <div className="p-4 safe-area-top">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl overflow-hidden neon-glow">
                <img src="/logo.jpeg" alt="KinoMir" className="w-full h-full object-cover" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-white neon-text">KinoMir</h1>
                <p className="text-xs text-gray-500">Premium Cinema</p>
              </div>
            </div>
            <button onClick={onClose} className="p-2 text-gray-400">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Profile Section */}
          {profile && (
            <div className="mb-6 p-3 bg-[#1a1a2e] rounded-xl neon-border">
              <div className="flex items-center gap-3 mb-3">
                {profile.photoUrl ? (
                  <img src={profile.photoUrl} alt="" className="w-10 h-10 rounded-full" />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-[#ff2d92]/30 flex items-center justify-center">
                    <User className="w-5 h-5 text-[#ff2d92]" />
                  </div>
                )}
                <div>
                  <p className="text-white font-medium">{profile.firstName} {profile.lastName}</p>
                  <p className="text-xs text-gray-500">@{profile.username || 'user'}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2 text-center">
                <div className="bg-black/30 rounded-lg p-2">
                  <p className="text-[#ff2d92] font-bold">{profile.moviesWatched || 0}</p>
                  <p className="text-xs text-gray-400">Фильмов</p>
                </div>
                <div className="bg-black/30 rounded-lg p-2">
                  <p className="text-[#ff2d92] font-bold">{profile.seriesWatched || 0}</p>
                  <p className="text-xs text-gray-400">Сериалов</p>
                </div>
                <div className="bg-black/30 rounded-lg p-2">
                  <p className="text-[#ff2d92] font-bold">{Math.floor((profile.watchTime || 0) / 60)}ч</p>
                  <p className="text-xs text-gray-400">Время</p>
                </div>
                <div className="bg-black/30 rounded-lg p-2">
                  <p className="text-[#ff2d92] font-bold text-xs truncate">{profile.favoriteGenre || '—'}</p>
                  <p className="text-xs text-gray-400">Жанр</p>
                </div>
              </div>
              {profile.currentlyWatching && (
                <div className="mt-2 p-2 bg-[#ff2d92]/10 rounded-lg flex items-center gap-2">
                  <Eye className="w-4 h-4 text-[#ff2d92]" />
                  <span className="text-xs text-gray-300 truncate">Смотрит: {profile.currentlyWatching.title}</span>
                </div>
              )}
            </div>
          )}

          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wider flex items-center gap-2">
                <Heart className="w-4 h-4 text-[#ff2d92]" />
                Избранное
              </h2>
              {favorites.length > 0 && (
                <button onClick={onClearFavorites} className="text-xs text-gray-500 hover:text-red-400">
                  Очистить
                </button>
              )}
            </div>

            {favorites.length > 0 ? (
              <div className="space-y-2">
                {favorites.map(movie => (
                  <div
                    key={`${movie.id}-${movie.type}`}
                    className="flex items-center gap-3 p-2 rounded-lg hover:bg-white/5 transition-colors group cursor-pointer"
                    onClick={() => { onSelectMovie(movie); onClose() }}
                  >
                    <img
                      src={movie.poster || '/placeholder.jpg'}
                      alt={movie.title}
                      className="w-12 h-16 object-cover rounded-lg"
                      loading="lazy"
                    />
                    <div className="flex-1 min-w-0">
                      <h3 className="text-sm font-medium text-white truncate">{movie.title}</h3>
                      <p className="text-xs text-gray-500">{movie.year}</p>
                    </div>
                    <button
                      onClick={e => { e.stopPropagation(); onRemoveFavorite(movie.id) }}
                      className="p-2 text-gray-500 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="empty-state rounded-xl p-6 text-center">
                <Heart className="w-10 h-10 text-gray-600 mx-auto mb-2" />
                <p className="text-sm text-gray-500">Пусто</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  )
})

// Movie Details Modal
const MovieDetailsModal = memo(function MovieDetailsModal({ 
  movie, 
  isOpen, 
  onClose,
  isFavorite,
  onToggleFavorite,
  onProfileUpdate
}: { 
  movie: Movie | null
  isOpen: boolean
  onClose: () => void
  isFavorite: boolean
  onToggleFavorite: () => void
  onProfileUpdate: (profile: UserProfile) => void
}) {
  const [details, setDetails] = useState<MovieDetails | null>(null)
  const [loading, setLoading] = useState(false)
  const [showPlayer, setShowPlayer] = useState(false)

  useEffect(() => {
    if (isOpen && movie?.id) {
      setLoading(true)
      setShowPlayer(false)
      setDetails(null)
      
      const controller = new AbortController()
      
      fetch(`/api/movie?id=${movie.id}&type=${movie.type}`, { signal: controller.signal })
        .then(res => res.json())
        .then(data => {
          if (data.success) {
            setDetails(data.movie)
          }
        })
        .catch(err => {
          if (err.name !== 'AbortError') console.error(err)
        })
        .finally(() => setLoading(false))
      
      return () => controller.abort()
    }
  }, [isOpen, movie?.id, movie?.type])

  useEffect(() => {
    document.body.style.overflow = isOpen ? 'hidden' : ''
    return () => { document.body.style.overflow = '' }
  }, [isOpen])
  
  // Track when player is shown - update profile stats
  useEffect(() => {
    if (showPlayer && movie) {
      // Small delay to ensure user actually started watching
      const timer = setTimeout(() => {
        handleWatchStart()
      }, 2000) // After 2 seconds of watching
      
      return () => clearTimeout(timer)
    }
  }, [showPlayer, movie])

  const handleEpisodeChange = useCallback((season: number, episode: number) => {
    if (details) {
      setDetails(prev => prev ? {
        ...prev,
        currentSeason: season,
        currentEpisode: episode,
        players: prev.players.map(p => ({
          ...p,
          url: p.url.replace(/\/\d+\/\d+$/, `/${season}/${episode}`)
        }))
      } : null)
      setShowPlayer(true)
    }
  }, [details])

  const handleWatchStart = useCallback(() => {
    if (movie) {
      addToHistory(movie)
      // Update profile in localStorage
      const genres = (details?.genres || movie.genres || [])
      const updated = updateProfileOnWatch(movie, genres)
      if (updated) {
        onProfileUpdate(updated)
      }
    }
  }, [movie, details?.genres, onProfileUpdate])

  if (!isOpen || !movie) return null

  const display = details || movie

  return (
    <div className="fixed inset-0 z-50 bg-[#0a0a0f] overflow-y-auto animate-fade-in">
      <div className="min-h-full safe-area-top safe-area-bottom pb-28">
        <button
          onClick={onClose}
          className="fixed top-4 left-4 z-20 p-2 bg-black/50 backdrop-blur-sm rounded-full text-white"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        <div className="relative h-72">
          {display.backdrop ? (
            <img src={display.backdrop} alt={display.title} className="w-full h-full object-cover" loading="lazy" />
          ) : display.poster ? (
            <img src={display.poster} alt={display.title} className="w-full h-full object-cover" loading="lazy" />
          ) : (
            <div className="w-full h-full bg-[#1a1a2e]" />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0f] via-[#0a0a0f]/60 to-transparent" />
        </div>

        <div className="relative -mt-24 px-4">
          <div className="flex gap-4">
            <div className="w-28 flex-shrink-0">
              {display.poster && (
                <img src={display.poster} alt={display.title} className="w-full rounded-xl shadow-2xl neon-border" loading="lazy" />
              )}
            </div>
            <div className="flex-1 pt-12">
              <h1 className="text-xl font-bold text-white neon-text">{display.title}</h1>
              {display.originalTitle && display.originalTitle !== display.title && (
                <p className="text-sm text-gray-400 mt-1">{display.originalTitle}</p>
              )}
              <div className="flex items-center gap-3 mt-2">
                {display.rating > 0 && <RatingBadge rating={display.rating} />}
                {display.votes && <span className="text-xs text-gray-400">{display.votes} голосов</span>}
              </div>
            </div>
          </div>

          <div className="mt-4 flex flex-wrap gap-4 text-sm text-gray-400">
            {display.year && (
              <div className="flex items-center gap-1">
                <Clock className="w-4 h-4 text-[#ff2d92]" />
                <span>{display.year}</span>
              </div>
            )}
            {details?.runtime && (
              <div className="flex items-center gap-1">
                <Clock className="w-4 h-4 text-[#ff2d92]" />
                <span>{details.runtime} мин</span>
              </div>
            )}
            {details?.country && (
              <div className="flex items-center gap-1">
                <span className="text-[#ff2d92]">🌍</span>
                <span>{details.country}</span>
              </div>
            )}
          </div>

          <div className="mt-3 flex flex-wrap gap-2">
            {display.genres?.map(g => (
              <span key={g} className="px-3 py-1 bg-[#1a1a2e] rounded-full text-sm text-gray-300 neon-border">
                {g}
              </span>
            ))}
          </div>

          {showPlayer && details?.players && details.players.length > 0 && (
            <div className="mt-6">
              <VideoPlayer 
                players={details.players} 
                title={display.title}
                onWatchStart={handleWatchStart}
              />
              
              {details.type === 'tv' && details.seasons && (
                <EpisodeSelector
                  seasons={details.seasons}
                  currentSeason={details.currentSeason || 1}
                  currentEpisode={details.currentEpisode || 1}
                  onSelect={handleEpisodeChange}
                />
              )}
            </div>
          )}

          {display.description && (
            <div className="mt-6">
              <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-2">Описание</h3>
              <p className="text-gray-300 leading-relaxed">{display.description}</p>
            </div>
          )}

          {details?.director && (
            <div className="mt-4">
              <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-1">Режиссёр</h3>
              <p className="text-white">{details.director}</p>
            </div>
          )}

          {details?.actors && details.actors.length > 0 && (
            <div className="mt-4">
              <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-2">Актёры</h3>
              <div className="flex gap-3 overflow-x-auto hide-scrollbar py-2">
                {details.actors.map((actor, i) => (
                  <div key={i} className="flex-shrink-0 text-center">
                    <div className="w-14 h-14 rounded-full overflow-hidden bg-[#1a1a2e] neon-border">
                      {actor.photo ? (
                        <img src={actor.photo} alt={actor.name} className="w-full h-full object-cover" loading="lazy" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-gray-500">👤</div>
                      )}
                    </div>
                    <p className="text-xs text-white mt-1 w-14 truncate">{actor.name}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {loading && (
          <div className="fixed inset-0 bg-[#0a0a0f]/80 flex items-center justify-center z-20">
            <div className="loading-spinner" />
          </div>
        )}
      </div>

      <div className="fixed bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-[#0a0a0f] via-[#0a0a0f] to-transparent safe-area-bottom z-30">
        <div className="flex gap-3">
          <button 
            onClick={() => setShowPlayer(!showPlayer)}
            className="btn-neon flex-1 py-4 rounded-xl flex items-center justify-center gap-2"
          >
            <Play className="w-5 h-5 fill-white" />
            {showPlayer ? 'Скрыть плеер' : 'Смотреть'}
          </button>
          <button 
            onClick={onToggleFavorite}
            className={`favorite-btn p-4 rounded-xl bg-[#1a1a2e] neon-border ${isFavorite ? 'active text-[#ff2d92]' : 'text-white'}`}
          >
            <Heart className={`w-5 h-5 ${isFavorite ? 'fill-current' : ''}`} />
          </button>
          <button className="p-4 rounded-xl bg-[#1a1a2e] neon-border text-white">
            <Share2 className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  )
})

// Search Modal
const SearchModal = memo(function SearchModal({ 
  isOpen, 
  onClose, 
  onSelectMovie,
  favorites,
  onToggleFavorite 
}: { 
  isOpen: boolean
  onClose: () => void
  onSelectMovie: (movie: Movie) => void
  favorites: Movie[]
  onToggleFavorite: (movie: Movie) => void
}) {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<Movie[]>([])
  const [loading, setLoading] = useState(false)
  const [searchHistory, setSearchHistory] = useState<string[]>([])

  useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        const history = JSON.parse(localStorage.getItem('kinomir_search_history') || '[]')
        setSearchHistory(history.slice(0, 5))
      } catch {}
    }
  }, [isOpen])

  useEffect(() => {
    if (!query.trim()) { 
      setResults([])
      return 
    }
    
    const controller = new AbortController()
    
    setLoading(true)
    fetch(`/api/search?q=${encodeURIComponent(query)}`, { signal: controller.signal })
      .then(res => res.json())
      .then(data => setResults(data.results || []))
      .catch(err => {
        if (err.name !== 'AbortError') console.error(err)
      })
      .finally(() => setLoading(false))
    
    return () => controller.abort()
  }, [query])

  const isFav = useCallback((id: string) => favorites.some(f => f.id === id), [favorites])
  
  const handleSelectMovie = useCallback((movie: Movie) => {
    if (query.trim()) {
      const newHistory = [query, ...searchHistory.filter(h => h !== query)].slice(0, 5)
      setSearchHistory(newHistory)
      localStorage.setItem('kinomir_search_history', JSON.stringify(newHistory))
    }
    onSelectMovie(movie)
    onClose()
  }, [query, searchHistory, onSelectMovie, onClose])
  
  const handleToggleFavorite = useCallback((e: React.MouseEvent, movie: Movie) => {
    e.stopPropagation()
    onToggleFavorite(movie)
  }, [onToggleFavorite])

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 bg-[#0a0a0f] animate-fade-in">
      <div className="flex flex-col h-full safe-area-top safe-area-bottom">
        <div className="flex items-center gap-3 p-4 border-b border-[#ff2d92]/20">
          <button onClick={onClose} className="p-2 text-gray-400">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#ff2d92]" />
            <input
              type="text"
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Поиск фильмов и сериалов..."
              className="input-neon w-full pl-10 pr-4 py-3 rounded-xl"
              autoFocus
            />
          </div>
        </div>
        <div className="flex-1 overflow-y-auto p-4">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="loading-spinner" />
            </div>
          ) : results.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {results.map(movie => (
                <MovieCard
                  key={`${movie.id}-${movie.type}`}
                  movie={movie}
                  onClick={() => handleSelectMovie(movie)}
                  isFavorite={isFav(movie.id)}
                  onToggleFavorite={e => handleToggleFavorite(e, movie)}
                />
              ))}
            </div>
          ) : query ? (
            <div className="flex flex-col items-center justify-center py-12 text-gray-500">
              <Search className="w-12 h-12 mb-4 opacity-50" />
              <p>Ничего не найдено</p>
            </div>
          ) : (
            <div className="py-4">
              {searchHistory.length > 0 && (
                <div className="mb-6">
                  <h3 className="text-sm text-gray-400 mb-3">Недавние поиски</h3>
                  <div className="flex flex-wrap gap-2">
                    {searchHistory.map((term, i) => (
                      <button
                        key={i}
                        onClick={() => setQuery(term)}
                        className="px-3 py-1.5 bg-[#1a1a2e] rounded-full text-sm text-gray-300 neon-border hover:text-white"
                      >
                        {term}
                      </button>
                    ))}
                  </div>
                </div>
              )}
              <div className="flex flex-col items-center justify-center py-8 text-gray-500">
                <Sparkles className="w-12 h-12 mb-4 opacity-50" />
                <p>Введите название фильма</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
})

// Main Component
export default function Home() {
  const [trending, setTrending] = useState<Movie[]>([])
  const [topRated, setTopRated] = useState<Movie[]>([])
  const [nowPlaying, setNowPlaying] = useState<Movie[]>([])
  const [popularTV, setPopularTV] = useState<Movie[]>([])
  const [loading, setLoading] = useState(true)
  const [favorites, setFavorites] = useState<Movie[]>([])
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [searchOpen, setSearchOpen] = useState(false)
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null)
  const [detailsOpen, setDetailsOpen] = useState(false)
  const [category, setCategory] = useState<'all' | 'movies' | 'tv'>('all')

  // Initialize Telegram WebApp and load profile from localStorage
  useEffect(() => {
    // Load favorites
    setFavorites(getFavorites())
    
    // Initialize Telegram WebApp
    if (typeof window !== 'undefined') {
      // Wait for Telegram SDK to load
      const initTg = () => {
        const tg = (window as any).Telegram?.WebApp
        if (tg) {
          tg.ready()
          tg.expand()
        }
      }
      
      // Try immediately or wait a bit for script load
      if ((window as any).Telegram) {
        initTg()
      } else {
        setTimeout(initTg, 100)
      }
      
      // Load or create profile from localStorage
      const savedProfile = localStorage.getItem(PROFILE_KEY)
      let baseProfile: UserProfile | null = null
      
      if (savedProfile) {
        try {
          baseProfile = JSON.parse(savedProfile)
        } catch {}
      }
      
      // Get user from Telegram with retry
      const getTelegramUser = () => {
        const user = (window as any).Telegram?.WebApp?.initDataUnsafe?.user
        if (user) {
          return user
        }
        return null
      }
      
      // Try to get Telegram user immediately and with delay
      const tgUser = getTelegramUser()
      
      if (tgUser) {
        // Telegram user found - create/update profile
        const updated: UserProfile = {
          id: baseProfile?.id || `tg_${tgUser.id}`,
          telegramId: tgUser.id,
          username: tgUser.username || baseProfile?.username,
          firstName: tgUser.first_name || baseProfile?.firstName,
          lastName: tgUser.last_name || baseProfile?.lastName,
          photoUrl: tgUser.photo_url || baseProfile?.photoUrl,
          moviesWatched: baseProfile?.moviesWatched || 0,
          seriesWatched: baseProfile?.seriesWatched || 0,
          favoriteGenre: baseProfile?.favoriteGenre || '—',
          currentlyWatching: baseProfile?.currentlyWatching,
          watchTime: baseProfile?.watchTime || 0,
          createdAt: baseProfile?.createdAt || new Date().toISOString()
        }
        localStorage.setItem(PROFILE_KEY, JSON.stringify(updated))
        setProfile(updated)
      } else if (baseProfile) {
        // Use saved profile
        setProfile(baseProfile)
      } else {
        // Create guest profile for non-Telegram environment
        const guestProfile: UserProfile = {
          id: `guest_${Date.now()}`,
          telegramId: 0,
          username: 'Гость',
          firstName: 'Гость',
          lastName: '',
          photoUrl: undefined,
          moviesWatched: 0,
          seriesWatched: 0,
          favoriteGenre: '—',
          watchTime: 0,
          createdAt: new Date().toISOString()
        }
        localStorage.setItem(PROFILE_KEY, JSON.stringify(guestProfile))
        setProfile(guestProfile)
      }
      
      // Retry getting Telegram user after SDK fully loads
      setTimeout(() => {
        const retryUser = getTelegramUser()
        if (retryUser) {
          setProfile(prev => {
            const updated: UserProfile = {
              id: prev?.id || `tg_${retryUser.id}`,
              telegramId: retryUser.id,
              username: retryUser.username || prev?.username,
              firstName: retryUser.first_name || prev?.firstName,
              lastName: retryUser.last_name || prev?.lastName,
              photoUrl: retryUser.photo_url || prev?.photoUrl,
              moviesWatched: prev?.moviesWatched || 0,
              seriesWatched: prev?.seriesWatched || 0,
              favoriteGenre: prev?.favoriteGenre || '—',
              currentlyWatching: prev?.currentlyWatching,
              watchTime: prev?.watchTime || 0,
              createdAt: prev?.createdAt || new Date().toISOString()
            }
            localStorage.setItem(PROFILE_KEY, JSON.stringify(updated))
            return updated
          })
        }
      }, 500)
    }
  }, [])

  // Load movies
  useEffect(() => {
    const controller = new AbortController()
    
    setLoading(true)
    fetch(`/api/movies?type=${category}`, { signal: controller.signal })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          setTrending(data.trending || [])
          setTopRated(data.topRated || [])
          setNowPlaying(data.nowPlaying || [])
          setPopularTV(data.popularTV || [])
        }
      })
      .catch(err => {
        if (err.name !== 'AbortError') console.error(err)
      })
      .finally(() => setLoading(false))
    
    return () => controller.abort()
  }, [category])

  const toggleFavorite = useCallback((movie: Movie) => {
    setFavorites(prev => {
      const exists = prev.some(f => f.id === movie.id)
      const next = exists ? prev.filter(f => f.id !== movie.id) : [...prev, movie]
      saveFavorites(next)
      return next
    })
  }, [])

  const isFav = useCallback((id: string) => favorites.some(f => f.id === id), [favorites])

  const handleMovieClick = useCallback((movie: Movie) => {
    setSelectedMovie(movie)
    setDetailsOpen(true)
  }, [])

  const handleCloseDetails = useCallback(() => {
    setDetailsOpen(false)
    setSelectedMovie(null)
  }, [])

  const handleSelectFavorite = useCallback((movie: Movie) => {
    setSelectedMovie(movie)
    setDetailsOpen(true)
  }, [])

  const handleRemoveFavorite = useCallback((id: string) => {
    setFavorites(prev => {
      const next = prev.filter(f => f.id !== id)
      saveFavorites(next)
      return next
    })
  }, [])

  const handleClearFavorites = useCallback(() => {
    setFavorites([])
    saveFavorites([])
  }, [])

  const categories = useMemo(() => [
    { id: 'all', label: 'Все', icon: Sparkles },
    { id: 'movies', label: 'Фильмы', icon: Film },
    { id: 'tv', label: 'Сериалы', icon: Tv }
  ], [])

  return (
    <div className="min-h-screen bg-[#0a0a0f] pb-24">
      <header className="sticky top-0 z-40 bg-[#0a0a0f]/80 backdrop-blur-lg border-b border-[#ff2d92]/20 safe-area-top">
        <div className="px-4 py-3 flex items-center gap-4">
          <button onClick={() => setSidebarOpen(true)} className="p-2 text-gray-400">
            <Menu className="w-6 h-6" />
          </button>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg overflow-hidden neon-glow">
              <img src="/logo.jpeg" alt="KinoMir" className="w-full h-full object-cover" />
            </div>
            <span className="font-bold text-white neon-text">KinoMir</span>
          </div>
          <div className="flex-1" />
          <button onClick={() => setSearchOpen(true)} className="p-2 text-gray-400">
            <Search className="w-5 h-5" />
          </button>
        </div>
      </header>

      <div className="px-4 py-4 overflow-x-auto hide-scrollbar">
        <div className="flex gap-2">
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setCategory(cat.id as typeof category)}
              className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap ${
                category === cat.id
                  ? 'bg-gradient-to-r from-[#ff2d92] to-[#ff6eb4] text-white neon-glow'
                  : 'bg-[#1a1a2e] text-gray-400 neon-border'
              }`}
            >
              <cat.icon className="w-4 h-4" />
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      <main className="pb-8">
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="loading-spinner" />
          </div>
        ) : (
          <>
            {/* Trending - different content based on category */}
            {trending.length > 0 && (
              <section className="mb-8">
                <div className="section-header px-4 py-2 mb-4 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#ff2d92]" />
                  <h2 className="text-lg font-bold text-white">
                    {category === 'movies' ? 'Популярные фильмы' : category === 'tv' ? 'Популярные сериалы' : 'В тренде'}
                  </h2>
                </div>
                <div className="px-4 overflow-x-auto hide-scrollbar">
                  <div className="flex gap-3">
                    {trending
                      .filter(m => category === 'all' || m.type === category.slice(0, -1))
                      .slice(0, 30)
                      .map(movie => (
                        <MovieCard
                          key={`${movie.id}-${movie.type}`}
                          movie={movie}
                          onClick={() => handleMovieClick(movie)}
                          isFavorite={isFav(movie.id)}
                          onToggleFavorite={e => { e.stopPropagation(); toggleFavorite(movie) }}
                        />
                      ))}
                  </div>
                </div>
              </section>
            )}

            {/* Top Rated - Movies only */}
            {(category === 'all' || category === 'movies') && topRated.length > 0 && (
              <section className="mb-8">
                <div className="section-header px-4 py-2 mb-4 flex items-center gap-2">
                  <Star className="w-4 h-4 text-[#ff2d92]" />
                  <h2 className="text-lg font-bold text-white">Топ фильмы</h2>
                </div>
                <div className="px-4 overflow-x-auto hide-scrollbar">
                  <div className="flex gap-3">
                    {topRated.slice(0, 30).map(movie => (
                      <MovieCard
                        key={`${movie.id}-${movie.type}`}
                        movie={movie}
                        onClick={() => handleMovieClick(movie)}
                        isFavorite={isFav(movie.id)}
                        onToggleFavorite={e => { e.stopPropagation(); toggleFavorite(movie) }}
                      />
                    ))}
                  </div>
                </div>
              </section>
            )}

            {/* Now Playing - Movies only */}
            {(category === 'all' || category === 'movies') && nowPlaying.length > 0 && (
              <section className="mb-8">
                <div className="section-header px-4 py-2 mb-4 flex items-center gap-2">
                  <Play className="w-4 h-4 text-[#ff2d92]" />
                  <h2 className="text-lg font-bold text-white">Смотрят сейчас</h2>
                </div>
                <div className="px-4 overflow-x-auto hide-scrollbar">
                  <div className="flex gap-3">
                    {nowPlaying.slice(0, 30).map(movie => (
                      <MovieCard
                        key={`${movie.id}-${movie.type}`}
                        movie={movie}
                        onClick={() => handleMovieClick(movie)}
                        isFavorite={isFav(movie.id)}
                        onToggleFavorite={e => { e.stopPropagation(); toggleFavorite(movie) }}
                      />
                    ))}
                  </div>
                </div>
              </section>
            )}

            {/* Popular TV - TV only */}
            {(category === 'all' || category === 'tv') && popularTV.length > 0 && (
              <section className="mb-8">
                <div className="section-header px-4 py-2 mb-4 flex items-center gap-2">
                  <Tv className="w-4 h-4 text-[#ff2d92]" />
                  <h2 className="text-lg font-bold text-white">Популярные сериалы</h2>
                </div>
                <div className="px-4 overflow-x-auto hide-scrollbar">
                  <div className="flex gap-3">
                    {popularTV.slice(0, 40).map(movie => (
                      <MovieCard
                        key={`${movie.id}-${movie.type}`}
                        movie={movie}
                        onClick={() => handleMovieClick(movie)}
                        isFavorite={isFav(movie.id)}
                        onToggleFavorite={e => { e.stopPropagation(); toggleFavorite(movie) }}
                      />
                    ))}
                  </div>
                </div>
              </section>
            )}

            {/* Top TV Shows */}
            {(category === 'all' || category === 'tv') && popularTV.length > 10 && (
              <section className="mb-8">
                <div className="section-header px-4 py-2 mb-4 flex items-center gap-2">
                  <Star className="w-4 h-4 text-[#ff2d92]" />
                  <h2 className="text-lg font-bold text-white">Топ сериалы</h2>
                </div>
                <div className="px-4 overflow-x-auto hide-scrollbar">
                  <div className="flex gap-3">
                    {popularTV
                      .filter(m => m.rating >= 7)
                      .slice(0, 30)
                      .map(movie => (
                        <MovieCard
                          key={`${movie.id}-${movie.type}`}
                          movie={movie}
                          onClick={() => handleMovieClick(movie)}
                          isFavorite={isFav(movie.id)}
                          onToggleFavorite={e => { e.stopPropagation(); toggleFavorite(movie) }}
                        />
                      ))}
                  </div>
                </div>
              </section>
            )}
          </>
        )}
      </main>

      <nav className="bottom-nav safe-area-bottom">
        <div className="flex items-center justify-around py-2">
          <button className="bottom-nav-item active flex flex-col items-center gap-1 p-2">
            <Film className="w-5 h-5" />
            <span className="text-xs">Главная</span>
          </button>
          <button onClick={() => setSearchOpen(true)} className="bottom-nav-item flex flex-col items-center gap-1 p-2 text-gray-400">
            <Search className="w-5 h-5" />
            <span className="text-xs">Поиск</span>
          </button>
          <button onClick={() => setSidebarOpen(true)} className="bottom-nav-item flex flex-col items-center gap-1 p-2 text-gray-400">
            <Heart className="w-5 h-5" />
            <span className="text-xs">Избранное</span>
          </button>
        </div>
      </nav>

      <Sidebar
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        favorites={favorites}
        onSelectMovie={handleSelectFavorite}
        onRemoveFavorite={handleRemoveFavorite}
        onClearFavorites={handleClearFavorites}
        profile={profile}
      />

      <SearchModal
        isOpen={searchOpen}
        onClose={() => setSearchOpen(false)}
        onSelectMovie={handleMovieClick}
        favorites={favorites}
        onToggleFavorite={toggleFavorite}
      />

      {detailsOpen && selectedMovie && (
        <MovieDetailsModal
          movie={selectedMovie}
          isOpen={detailsOpen}
          onClose={handleCloseDetails}
          isFavorite={isFav(selectedMovie.id)}
          onToggleFavorite={() => toggleFavorite(selectedMovie)}
          onProfileUpdate={setProfile}
        />
      )}
    </div>
  )
}
