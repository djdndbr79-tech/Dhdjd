import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin", "cyrillic"],
});

export const metadata: Metadata = {
  title: "KinoMir - Премиум Онлайн Кинотеатр",
  description: "Смотрите фильмы и сериалы онлайн в HD качестве. Большой выбор новинок и классики. Премиум онлайн кинотеатр.",
  icons: {
    icon: "/logo.jpeg",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: "#0a0a0f",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru" suppressHydrationWarning>
      <head>
        <script src="https://telegram.org/js/telegram-web-app.js" async></script>
      </head>
      <body
        className={`${inter.variable} font-sans antialiased`}
        style={{
          backgroundColor: 'var(--tg-theme-bg-color, #0a0a0f)',
          color: 'var(--tg-theme-text-color, #ffffff)',
        }}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
